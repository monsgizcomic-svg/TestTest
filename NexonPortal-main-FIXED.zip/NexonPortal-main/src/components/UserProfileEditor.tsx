import React, { useState, useEffect } from "react";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { User as FirebaseUser } from "firebase/auth";
import { db, handleFirestoreError, OperationType } from "../lib/firebase";
import { 
  User, 
  Building, 
  GraduationCap, 
  Save, 
  X, 
  Mail,
  Loader
} from "lucide-react";

interface UserProfileEditorProps {
  user: FirebaseUser;
  onClose: () => void;
  onSaveSuccess: (updatedProfile: { name: string; role: string; grade: string; school: string }) => void;
  onAddNotification: (title: string, msg: string) => void;
}

export default function UserProfileEditor({ user, onClose, onSaveSuccess, onAddNotification }: UserProfileEditorProps) {
  const [name, setName] = useState("");
  const [role, setRole] = useState("Member");
  const [grade, setGrade] = useState("Member");
  const [school, setSchool] = useState("-");
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);

  useEffect(() => {
    async function loadProfile() {
      try {
        const docRef = doc(db, "users", user.uid);
        const docSnap = await getDoc(docRef).catch((error) => {
          handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
          throw error;
        });
        if (docSnap.exists()) {
          const data = docSnap.data();
          setName(data.name || user.displayName || user.email?.split("@")[0] || "User");
          setRole(data.role || "Member");
          setGrade(data.grade || "Member");
          setSchool(data.school || "-");
        } else {
          // Fallback to displayName or email prefix
          setName(user.displayName || user.email?.split("@")[0] || "User Nexon");
        }
      } catch (err) {
        console.warn("Soft warning: fetching user profile from Firestore:", err);
        setName(user.displayName || "User Nexon");
      } finally {
        setFetching(false);
      }
    }
    loadProfile();
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;

    setLoading(true);

    const updatedProfile = { name, role, grade, school };

    try {
      const docRef = doc(db, "users", user.uid);
      await setDoc(docRef, {
        name,
        role,
        grade,
        school,
        email: user.email,
        updatedAt: new Date().toISOString()
      }, { merge: true }).catch((error) => {
        handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
        throw error;
      });

      onSaveSuccess(updatedProfile);
      onAddNotification("Profil Diperbarui! ✨", "Perubahan profil Anda berhasil disimpan secara pribadi ke Firestore.");
      onClose();
    } catch (err) {
      console.error("Error saving profile update to Firestore:", err);
      onAddNotification("Error ❌", "Terjadi kesalahan saat menyimpan profil ke server.");
    } finally {
      setLoading(false);
    }
  };

  if (fetching) {
    return (
      <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center backdrop-blur-sm animate-fadeIn">
        <div className="bg-[#0d0f17] border border-white/10 rounded-2xl p-6 text-center space-y-3">
          <Loader className="w-6 h-6 text-indigo-400 animate-spin mx-auto" />
          <p className="text-xs text-white/50 font-mono">Memuat detail profil dari Firestore...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fadeIn" id="user_profile_editor_overlay">
      <div className="bg-[#0d0f17] border border-white/10 rounded-2xl max-w-md w-full relative overflow-hidden shadow-2xl p-6 md:p-8 space-y-6" onClick={(e) => e.stopPropagation()}>
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 bg-white/5 hover:bg-white/10 rounded-full text-white/40 hover:text-white transition-colors cursor-pointer"
          title="Tutup Modal"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="space-y-1.5">
          <h3 className="text-lg font-black text-white leading-none">Edit Profil Nexon Anda</h3>
          <p className="text-xs text-white/50">Sesuaikan username atau nama lengkap Anda.</p>
        </div>

        {/* User Email Indicator */}
        <div className="flex items-center gap-2.5 p-3 bg-indigo-500/10 border border-indigo-500/20 rounded-xl">
          <Mail className="w-4 h-4 text-indigo-400 shrink-0" />
          <div className="text-left">
            <span className="block text-[9px] text-indigo-300 font-mono uppercase font-bold tracking-wider leading-none">Email Terdaftar</span>
            <span className="text-xs text-white/80 font-medium">{user.email}</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1 text-left">
            <label className="block text-[11px] font-bold text-white/60 tracking-wider uppercase font-mono">Nama Lengkap</label>
            <div className="relative">
              <User className="absolute left-3 top-3.5 w-4 h-4 text-white/30" />
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-[#12141c] border border-white/5 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white/90 outline-none focus:border-indigo-500/40"
                required
              />
            </div>
          </div>

          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 bg-white/5 hover:bg-white/10 text-white rounded-xl text-xs font-bold transition-all cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              {loading ? (
                <Loader className="w-4 h-4 animate-spin" />
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>Simpan Perubahan</span>
                </>
              )}
            </button>
          </div>
        </form>

      </div>
    </div>
  );
}
