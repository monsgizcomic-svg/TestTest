import { useState } from "react";
import { renderFormattedText } from "./DianaChat";
import { 
  Terminal, 
  Copy, 
  Check, 
  Code2, 
  Play, 
  Sparkles, 
  Bug, 
  HelpCircle,
  FileCode2,
  BookmarkCheck
} from "lucide-react";

interface NexonCodeStudioProps {
  onAddNotification: (title: string, msg: string) => void;
}

export default function NexonCodeStudio({ onAddNotification }: NexonCodeStudioProps) {
  const [prompt, setPrompt] = useState("");
  const [selectedLang, setSelectedLang] = useState("Python");
  const [isLoading, setIsLoading] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  
  const [result, setResult] = useState<{ code: string; explanation: string }>({
    code: `# Contoh Kode NexonCode\ndef hitung_kecepatan(jarak, waktu):\n    """Menghitung kecepatan rata-rata benda"""\n    if waktu == 0:\n        return "Waktu tidak boleh nol"\n    return jarak / waktu\n\n# Memanggil fungsi\nhasil = hitung_kecepatan(100, 5)\nprint(f"Kecepatan rata-rata: {hasil} m/s")`,
    explanation: "Ini adalah contoh kode awal bahasa Python. Tulis dan kirimkan prompt Anda ke kotak Masukan untuk menghasilkan kode kustom nyata bertenaga Gemini AI!"
  });

  const languages = ["Python", "JavaScript", "TypeScript", "HTML/CSS", "C++", "Java", "SQL"];

  const exampleCodingPrompts = [
    { label: "Fibonacci Recursion", q: "Buat algoritma deret Fibonacci secara rekursif lengkap dengan penjelasannya." },
    { label: "Validasi Form JS", q: "Bagaimana cara memvalidasi masukan alamat email dan kata sandi menggunakan regex di JavaScript?" },
    { label: "Koneksi Database", q: "Tulis kode koneksi database SQLite menggunakan Node.js dan cara query datanya." },
    { label: "Desain Flexbox CSS", q: "Buatkan contoh responsive card grid layout menggunakan HTML dasar dan CSS flexbox modern." }
  ];

  const handleGenerateCode = async () => {
    if (!prompt.trim()) return;

    setIsLoading(true);
    try {
      const response = await fetch("/api/code", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: prompt,
          language: selectedLang
        })
      });

      if (!response.ok) {
        let errMsg = `Server Error (Status: ${response.status})`;
        try {
          const text = await response.text();
          try {
            const errData = JSON.parse(text);
            if (errData && errData.error) {
              errMsg = errData.error;
            } else if (errData && errData.message) {
              errMsg = errData.message;
            }
          } catch {
            if (text) {
              const cleanText = text.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
              errMsg = cleanText.substring(0, 150) || errMsg;
            }
          }
        } catch {}
        throw new Error(errMsg);
      }

      const data = await response.json();
      setResult({
        code: data.code || "// Gagal men-generate baris kode",
        explanation: data.explanation || "Tidak ada penjelasan terlampir."
      });
      onAddNotification("NexonCode Siap!", `Kode bahasa ${selectedLang} berhasil di-generate.`);
    } catch (err: any) {
      setResult({
        code: `// Terjadi kesalahan: ${err.message}`,
        explanation: "Tidak bisa menghubungkan ke server NexonCode AI."
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(result.code);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
      onAddNotification("Disalin!", "Kode dipindahkan ke papan klip Anda.");
    } catch (err) {
      console.error("Gagal menyalin:", err);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5" id="nexoncode_studio_panel">
      
      {/* Target input on the left */}
      <div className="lg:col-span-12 xl:col-span-5 flex flex-col gap-4">
        
        {/* Workspace info & guidelines */}
        <div className="bg-[#0b0c10] text-[#e2e8f0] rounded-2xl p-5 border border-white/5 shadow-2xl">
          <div className="flex items-center gap-2 text-amber-405 text-amber-430 text-amber-400 font-semibold mb-2 text-base">
            <Code2 className="w-5 h-5 animate-pulse" />
            <span>NexonCode AI Studio</span>
          </div>
          <p className="text-xs text-white/60 leading-relaxed font-sans">
            Butuh bantuan tugas pemprograman, algoritma, atau mendesain web? Tanyakan langsung di sini! NexonCode akan menuliskan baris kode fungsional yang bisa langsung disalin.
          </p>

          {/* Quick Config */}
          <div className="mt-4 space-y-3">
            <label className="block text-xs font-semibold text-white/40 uppercase tracking-wider font-mono">
              Pilih Bahasa Pemrograman:
            </label>
            <div className="flex flex-wrap gap-1.5">
              {languages.map((lang) => (
                <button
                  key={lang}
                  type="button"
                  onClick={() => setSelectedLang(lang)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-mono border transition-all cursor-pointer ${
                    selectedLang === lang 
                      ? "bg-amber-500 border-amber-400 text-slate-950 shadow-md" 
                      : "bg-[#12141c] border-white/5 text-white/55 hover:border-white/20 hover:text-white"
                  }`}
                >
                  {lang}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* User prompt control */}
        <div className="bg-[#0b0c10] border border-white/5 rounded-2xl p-4 shadow-xl">
          <label className="block text-xs font-bold text-white/40 uppercase font-mono tracking-wider mb-2">
            Pertanyaan / Modul Kode Siswa:
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={4}
            placeholder={`contoh: Buat fungsi cek prima, atau Cara pasang laravel middleware...`}
            className="w-full p-3 bg-white/5 border border-white/10 rounded-xl focus:outline-hidden focus:ring-1.5 focus:ring-amber-500/40 focus:border-amber-500/50 text-sm placeholder-white/20 text-white font-sans"
          />

          <button
            type="button"
            disabled={isLoading || !prompt.trim()}
            onClick={handleGenerateCode}
            className="w-full mt-3 py-3 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-950 font-bold rounded-xl text-xs tracking-wider uppercase transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1.5 cursor-pointer"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin h-4 w-4 text-slate-950" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                <span className="font-mono">NexonCode sedang merakit logika...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-slate-950 animate-pulse" />
                <span>Rakit Kode Sekarang!</span>
              </>
            )}
          </button>
        </div>

        {/* Suggestion list */}
        <div className="bg-[#12141c] border border-white/5 rounded-2xl p-4 shadow-xl">
          <p className="text-[10px] font-bold text-white/30 uppercase tracking-widest mb-1.5 flex items-center gap-1 font-mono">
            <BookmarkCheck className="w-3.5 h-3.5 text-amber-500 animate-pulse" /> Contoh Kueri Cepat:
          </p>
          <div className="space-y-1.5">
            {exampleCodingPrompts.map((item, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setPrompt(item.q);
                  onAddNotification("Templat Terpilih", "Prompt kueri cepat disiapkan untuk disalin / diedit.");
                }}
                className="w-full text-left p-2 bg-white/5 hover:bg-amber-500/10 hover:border-amber-500/30 border border-white/5 rounded-lg text-[11px] font-medium text-white/80 hover:text-white truncate transition-colors cursor-pointer"
              >
                🔍 {item.label}
              </button>
            ))}
          </div>
        </div>

      </div>

      {/* Code viewport terminal on the right */}
      <div className="lg:col-span-12 xl:col-span-7 flex flex-col gap-4">
        
        {/* Ide Mockup */}
        <div className="bg-[#050608] rounded-2xl border border-white/5 shadow-2xl overflow-hidden flex-1 flex flex-col">
          {/* Editor Header Bar */}
          <div className="bg-[#0b0c10] border-b border-white/5 p-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex gap-1.5">
                <span className="w-3 h-3 rounded-full bg-rose-500 inline-block pointer-events-none"></span>
                <span className="w-3 h-3 rounded-full bg-amber-500 inline-block pointer-events-none"></span>
                <span className="w-3 h-3 rounded-full bg-green-500 inline-block pointer-events-none"></span>
              </div>
              <span className="text-[10px] font-mono font-semibold text-white/50 bg-white/5 px-2 py-0.5 rounded border border-white/5 ml-3 uppercase tracking-wide">
                editor.tsx
              </span>
            </div>
            
            <div className="flex items-center gap-3 font-mono">
              <span className="text-[11px] text-amber-400 font-semibold bg-amber-950/20 border border-amber-900/30 px-2 py-0.5 rounded">
                {selectedLang}
              </span>
              <button
                onClick={handleCopyCode}
                title="Salin Kode ke Clipboard"
                className="flex items-center gap-1 px-2.5 py-1.5 bg-white/5 hover:bg-white/10 text-white/80 hover:text-white border border-white/10 hover:border-white/20 rounded-lg text-xs font-semibold cursor-pointer transition-all"
              >
                {isCopied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-green-400 shrink-0 animate-pulse" />
                    <span className="text-green-400 font-semibold">Disalin!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 shrink-0" />
                    <span>Salin</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* IDE Content Screen */}
          <div className="flex-1 p-5 font-mono text-xs overflow-x-auto min-h-[250px] leading-relaxed text-indigo-200">
            <pre className="whitespace-pre">{result.code}</pre>
          </div>
        </div>

        {/* Explanation Module */}
        <div className="bg-[#0d0f17] border border-white/5 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center gap-2 font-bold text-amber-400 text-xs uppercase tracking-wider mb-2 font-mono">
            <Terminal className="w-4 h-4 text-amber-450 animate-pulse" />
            <span>Penjelasan Logika Pemrograman</span>
          </div>
          <div className="text-sm text-white/80 leading-relaxed font-sans">
            {renderFormattedText(result.explanation, "diana")}
          </div>
        </div>

      </div>

    </div>
  );
}
