import React, { useState, useEffect } from "react";
import { Reminder } from "../types";
import { 
  Bell, 
  Trash2, 
  Plus, 
  Volume2, 
  VolumeX, 
  Clock, 
  CheckCircle,
  Play,
  Heart,
  CalendarDays,
  Sparkles
} from "lucide-react";

interface SmartReminderProps {
  onAddNotification: (title: string, msg: string) => void;
}

export default function SmartReminder({ onAddNotification }: SmartReminderProps) {
  const [reminders, setReminders] = useState<Reminder[]>(() => {
    const saved = localStorage.getItem("nexon_reminders");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return [];
      }
    }
    return [
      {
        id: "rem-1",
        title: "Latihan Soal Kimia (NexonLab)",
        time: "19:00",
        days: ["Senin", "Rabu", "Jumat"],
        active: true,
        notes: "Mencoba simulasi reaktan reaktan baru bersama Ibu Diana."
      },
      {
        id: "rem-2",
        title: "Sesi Curhat Sehat Liana",
        time: "15:30",
        days: ["Selasa", "Kamis"],
        active: true,
        notes: "Melakukan pernapasan meditasi 4-4-5 bersama Ibu Liana untuk meredakan stres."
      }
    ];
  });

  const [newTitle, setNewTitle] = useState("");
  const [newTime, setNewTime] = useState("");
  const [newNotes, setNewNotes] = useState("");
  const [isMuted, setIsMuted] = useState(false);

  // Keep track of ticks to check for triggers
  const [currentTime, setCurrentTime] = useState(new Date());

  // Save to localStorage whenever reminders change
  useEffect(() => {
    localStorage.setItem("nexon_reminders", JSON.stringify(reminders));
  }, [reminders]);

  // Master Clock ticker checking every second
  useEffect(() => {
    const clockTimer = setInterval(() => {
      const now = new Date();
      setCurrentTime(now);

      // Check format e.g., "15:30"
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      const timeString = `${hours}:${minutes}`;

      // We trigger triggers on matching minute
      // To prevent multiple triggers in the same minute, we track matched IDs in state
      reminders.forEach((rem) => {
        if (rem.active && rem.time === timeString && !rem.triggeredToday) {
          triggerAlarm(rem);
          
          // Mark as triggered today for that minute
          setReminders(prev => prev.map(r => r.id === rem.id ? { ...r, triggeredToday: true } : r));
        }
      });

      // Reset triggered state at midnight
      if (hours === "00" && minutes === "00") {
        setReminders(prev => prev.map(r => ({ ...r, triggeredToday: false })));
      }

    }, 1000);

    return () => clearInterval(clockTimer);
  }, [reminders]);

  const triggerAlarm = (rem: Reminder) => {
    // 1. Fire onAddNotification callback (visual pop on screen)
    onAddNotification("⏰ PENGINGAT NexonAcademic!", `${rem.title}: ${rem.notes || "Waktunya mulai belajar!"}`);

    // 2. Play Audio Synthesis (TTS) - Speaks in Indonesian natively!
    if (!isMuted && "speechSynthesis" in window) {
      window.speechSynthesis.cancel(); // clear previous
      const textToSpeak = `Halo siswa nexon academic! Pengingat belajar mu sudah tiba. Sekarang waktunya untuk: ${rem.title}. Catatan tambahan: ${rem.notes || "mari belajar sejenak"}`;
      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      utterance.lang = "id-ID";
      utterance.rate = 1.0;
      window.speechSynthesis.speak(utterance);
    }

    // 3. Play Beep sound via Web Audio API context fallback
    if (!isMuted) {
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const oscillator = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(audioCtx.destination);

        oscillator.type = "sine";
        oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // high note
        gainNode.gain.setValueAtTime(0.5, audioCtx.currentTime);

        // start and stop pulse
        oscillator.start();
        oscillator.stop(audioCtx.currentTime + 1.2); 
      } catch (err) {
        console.warn("Audio Context blocked or not supported:", err);
      }
    }

    // 4. Trigger Haptic Vibration (on supported mobile devices)
    if ("vibrate" in navigator) {
      navigator.vibrate([200, 100, 200, 100, 300]);
    }
  };

  const handleAddReminder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newTime) return;

    const newRem: Reminder = {
      id: "rem-" + Date.now(),
      title: newTitle,
      time: newTime,
      days: ["Setiap Hari"],
      active: true,
      notes: newNotes
    };

    setReminders(prev => [...prev, newRem]);
    setNewTitle("");
    setNewTime("");
    setNewNotes("");
    onAddNotification("Pengingat Berhasil Dibuat!", `Materi "${newRem.title}" terdaftar jam ${newRem.time}.`);
  };

  const handleToggleActive = (id: string) => {
    setReminders(prev => prev.map(r => r.id === id ? { ...r, active: !r.active } : r));
  };

  const handleDeleteReminder = (id: string) => {
    setReminders(prev => prev.filter(r => r.id !== id));
    onAddNotification("Dihapus", "Jadwal sudah dibersihkan dari daftar.");
  };

  // Immediate Test Alarm mechanism
  const testAlarmImmediate = (rem: Reminder) => {
    triggerAlarm(rem);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5" id="smart_reminder_panel">
      
      {/* Alarm management and form on the left */}
      <div className="lg:col-span-12 xl:col-span-5 flex flex-col gap-4">
        
        {/* Clock showcase card */}
        <div className="bg-[#0b0c10] text-white rounded-2xl p-5 border border-white/5 shadow-2xl text-center space-y-2 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-5 text-indigo-400 font-bold font-mono text-[90px] select-none pointer-events-none">
            ⏰
          </div>
          <div className="text-indigo-455 text-indigo-400 uppercase tracking-widest text-[9px] font-bold font-mono animate-pulse">
            Waktu Aktual NexonAcademic
          </div>
          <div className="text-3xl font-black font-mono tracking-wider text-white">
            {currentTime.toLocaleTimeString("id", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
          </div>
          <div className="text-xs text-white/60 font-semibold font-mono">
            {currentTime.toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long" })}
          </div>

          <div className="pt-2.5 border-t border-white/5 mt-2 flex items-center justify-between text-xs">
            <span className="text-white/40 font-semibold font-mono">Suara Pasca-Alarm:</span>
            <button
              onClick={() => {
                setIsMuted(!isMuted);
                onAddNotification(isMuted ? "Suara Aktif" : "Senyap Diaktifkan", isMuted ? "Lonceng & suara TTS akan berbunyi." : "Alarm hanya muncul visual.");
              }}
              className="py-1.5 px-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 font-bold font-mono text-white/80 cursor-pointer flex items-center gap-1.5 text-[11px] transition-all"
            >
              {isMuted ? (
                <>
                  <VolumeX className="w-3.5 h-3.5 text-rose-400" /> <span>Mode Senyap</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5 text-amber-400 animate-pulse" /> <span>Suara Aktif</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Schedule Creation Box */}
        <div className="bg-[#0d0f17] border border-white/5 rounded-2xl p-5 shadow-2xl">
          <div className="flex items-center gap-2 border-b border-white/5 pb-3 mb-3">
            <Bell className="w-4.5 h-4.5 text-indigo-400 animate-bounce" />
            <h4 className="font-bold text-white text-sm font-sans">Tambahkan Pengingat Belajar</h4>
          </div>

          <form onSubmit={handleAddReminder} className="space-y-4">
            <div>
              <label className="block text-[10px] font-bold text-white/40 uppercase mb-1 font-mono">Mata Pelajaran / Sesi:</label>
              <input
                type="text"
                required
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="misal: Belajar Kimia Hidrogen, atau Curhat Liana"
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-xl focus:outline-hidden focus:ring-1.5 focus:ring-indigo-505 focus:ring-indigo-500/40 focus:border-indigo-500/40 text-xs text-white placeholder-white/20 font-sans"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-bold text-white/40 uppercase mb-1 font-mono">Waktu Alarm:</label>
                <input
                  type="time"
                  required
                  value={newTime}
                  onChange={(e) => setNewTime(e.target.value)}
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-xl focus:outline-hidden focus:ring-1.5 focus:ring-indigo-500/40 focus:border-indigo-500/40 text-xs font-mono text-white cursor-pointer"
                />
              </div>
              <div className="flex flex-col justify-end">
                <span className="text-[9px] text-[#e2e8f0]/40 font-mono leading-tight mb-1">Alarm berjalan setiap hari secara otomatis.</span>
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-white/40 uppercase mb-1 font-mono">Catatan Tambahan:</label>
              <textarea
                value={newNotes}
                onChange={(e) => setNewNotes(e.target.value)}
                rows={2}
                placeholder="misal: kerjakan kuis integral bab 4"
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-xl focus:outline-hidden focus:ring-1.5 focus:ring-indigo-500/40 focus:border-indigo-500/40 text-xs text-white placeholder-white/20 font-sans"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-indigo-500 to-teal-500 hover:from-indigo-600 hover:to-teal-600 text-white font-bold rounded-xl text-xs uppercase tracking-wider transition-all shadow-md cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Daftarkan Alarm</span>
            </button>
          </form>
        </div>

      </div>

      {/* Reminder list viewport on the right */}
      <div className="lg:col-span-12 xl:col-span-7 bg-[#0d0f17] border border-white/5 rounded-2xl p-5 shadow-2xl space-y-4">
        
        <div className="flex items-center justify-between border-b border-white/5 pb-3">
          <div>
            <h4 className="font-bold text-white text-sm flex items-center gap-1.5 font-sans">
              <CalendarDays className="w-4.5 h-4.5 text-indigo-400" />
              <span>Daftar Agenda Mengajar & Belajar Terjadwal</span>
            </h4>
            <p className="text-[11px] text-[#e2e8f0]/50 font-sans">Status alarm terus memantau jam internal browser Anda secara real-time</p>
          </div>
          <span className="text-xs bg-indigo-500/10 text-indigo-400 border border-indigo-500/30 font-bold px-2 py-1 rounded-md font-mono">
            {reminders.length} Terpasang
          </span>
        </div>

        {reminders.length === 0 ? (
          <div className="p-8 text-center bg-white/2 rounded-xl border border-dashed border-white/10 flex flex-col items-center">
            <span className="text-3xl">🏜️</span>
            <span className="text-sm font-semibold text-white/80 mt-2 font-mono">Belum ada Alarm terdaftar</span>
            <p className="text-xs text-white/40 max-w-[280px] mt-1 text-center leading-relaxed">
              Buat jadwal baru di form samping kiri untuk menerima notifikasi, suara alarm sintetis, serta getaran!
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {reminders.map((rem) => (
              <div
                key={rem.id}
                className={`p-4 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  rem.active 
                    ? "bg-[#12141c] border-white/10" 
                    : "bg-[#12141c]/40 border-white/5 opacity-40"
                }`}
              >
                <div className="flex items-start gap-4">
                  <div className={`p-2.5 rounded-xl shrink-0 mt-0.5 ${
                    rem.active ? "bg-indigo-500/10 text-indigo-400 border border-indigo-555 border-indigo-500/20" : "bg-white/5 text-white/20 border border-white/5"
                  }`}>
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-white text-sm font-sans">{rem.title}</span>
                      <span className="text-xs font-black font-mono bg-[#0d0f17] border border-indigo-500/25 text-indigo-400 px-1.5 py-0.5 rounded">
                        {rem.time}
                      </span>
                    </div>
                    <p className="text-xs text-white/60 mt-1 font-sans">{rem.notes || "Tidak ada rincian catatan khusus."}</p>
                    <div className="flex gap-1 items-center mt-2">
                      <span className="text-[9px] bg-white/5 text-white/50 border border-white/10 px-1.5 py-0.5 font-bold uppercase rounded font-mono">
                        Harian
                      </span>
                      {rem.triggeredToday && (
                        <span className="text-[9px] bg-green-500/10 text-green-400 border border-green-500/20 px-1.5 py-0.5 font-bold uppercase rounded font-mono flex items-center gap-0.5">
                          <CheckCircle className="w-2.5 h-2.5 text-green-400 animate-pulse" /> Sudah Bunyi Hari Ini
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 sm:self-center">
                  {/* Test Trigger Button */}
                  <button
                    onClick={() => testAlarmImmediate(rem)}
                    title="Uji coba alarm berbunyi secara instan"
                    className="p-1 px-2.5 hover:bg-white/5 text-indigo-400 rounded-lg text-xs cursor-pointer transition-colors border border-white/10 flex items-center gap-1 font-mono font-bold"
                  >
                    <Play className="w-3.5 h-3.5" /> <span>Uji</span>
                  </button>

                  {/* Switch Active Toggle */}
                  <button
                    onClick={() => handleToggleActive(rem.id)}
                    className={`py-1.5 px-3 rounded-lg text-xs font-mono font-bold cursor-pointer transition-all ${
                      rem.active 
                        ? "bg-green-500/15 hover:bg-green-555 hover:bg-green-500/35 text-green-400 border border-green-500/30" 
                        : "bg-white/5 hover:bg-white/10 text-white/40 border border-white/5"
                    }`}
                  >
                    {rem.active ? "Aktif" : "Mati"}
                  </button>

                  {/* Delete Button */}
                  <button
                    onClick={() => handleDeleteReminder(rem.id)}
                    title="Hapus Agenda"
                    className="p-1.5 hover:bg-rose-500/10 text-white/30 hover:text-rose-400 border border-white/10 hover:border-rose-500/25 rounded-lg cursor-pointer transition-all shrink-0"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Informative advice */}
        <div className="p-4 bg-indigo-950/20 border border-indigo-500/25 rounded-2xl text-xs text-indigo-200 flex items-start gap-2.5">
          <Sparkles className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5 animate-pulse" />
          <div>
            <span className="font-bold text-indigo-300 block mb-1">Mekanisme Cerdas Notifikasi Audio</span>
            Aliran alarm NexonAcademic menggunakan sintesis ucapan. Untuk memastikan suara ter-baca oleh peramban, jalankan setidaknya satu kali klik di manapun di halaman web agar izin Audio dilepas secara mandiri oleh sistem keamanan.
          </div>
        </div>

      </div>

    </div>
  );
}
