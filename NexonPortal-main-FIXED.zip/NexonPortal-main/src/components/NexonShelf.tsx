import React, { useState, useEffect, useRef } from "react";
import { 
  BookOpen, 
  ChevronLeft, 
  ChevronRight, 
  ZoomIn, 
  ZoomOut, 
  Maximize2, 
  Plus, 
  Trash2, 
  Edit, 
  Search, 
  Sparkles, 
  Grid, 
  Layers, 
  ArrowLeft, 
  Settings, 
  LogOut, 
  FileText, 
  UploadCloud, 
  CheckCircle2, 
  AlertCircle, 
  Loader2,
  Bookmark,
  ExternalLink,
  ShieldAlert,
  Lock,
  Unlock
} from "lucide-react";
import { collection, doc, getDocs, setDoc, deleteDoc, getDoc, query, orderBy } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../lib/firebase";

// Custom schemas inside component
export interface NexonWork {
  id: string;
  title: string;
  description: string;
  author: string;
  coverUrl: string;
  tags: string[];
  status: "Ongoing" | "Completed";
  episodeCount: number;
}

export interface NexonEpisode {
  id: string;
  workId: string;
  episodeNumber: number;
  title: string;
  pdfUrl: string;
  pagesCount?: number;
}

interface NexonShelfProps {
  userProfile: {
    name: string;
    role: string;
    grade: string;
    school: string;
  };
  onBackToPortal: () => void;
  onAddNotification: (title: string, msg: string) => void;
  currentUserId?: string;
}

// Built-in Sample High-Fidelity Comics for out-of-the-box enjoyment
const SAMPLE_WORKS: NexonWork[] = [
  {
    id: "nexon-chronicles-1",
    title: "Nexon Chronicles: Rise of the Code Masters",
    description: "Dalam masa depan cyberpunk di mana realitas terhubung langsung dengan compiler AI, sekelompok siswa Akademi Digital Nusantara menemukan celah sintaksis yang dapat memprogram ulang dunia nyata. Perjalanan epik pemuda Mons Giz mendaki menara NexonShelf!",
    author: "Zacky Akira (Dosen Nusantara)",
    coverUrl: "", // Generated dynamically in-app if empty
    tags: ["Sci-Fi", "Cyberpunk", "Edukasi", "Coding"],
    status: "Ongoing",
    episodeCount: 3
  },
  {
    id: "digital-alchemy",
    title: "The Digital Alchemist's Manual",
    description: "Petunjuk komprehensif memanipulasi grid quantum menggunakan D3 dan kimia komputasi. Temukan keajaiban reaktivitas molekul dwi-elemen dalam komik ilustrasi nan memukau.",
    author: "Fasilitator Budi Hartono",
    coverUrl: "",
    tags: ["Edukasi", "Sains", "Fantasy"],
    status: "Completed",
    episodeCount: 1
  }
];

const SAMPLE_EPISODES: NexonEpisode[] = [
  {
    id: "ep-1-nc",
    workId: "nexon-chronicles-1",
    episodeNumber: 1,
    title: "Ep 01: Sintaksis Quantum Pertama",
    pdfUrl: "https://raw.githubusercontent.com/mozilla/pdf.js/master/web/compressed.tracemonkey-pldi09.pdf"
  },
  {
    id: "ep-2-nc",
    workId: "nexon-chronicles-1",
    episodeNumber: 2,
    title: "Ep 02: Bug Di Tembok Virtual",
    pdfUrl: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf"
  },
  {
    id: "ep-3-nc",
    workId: "nexon-chronicles-1",
    episodeNumber: 3,
    title: "Ep 03: Compiler Semesta (CORS-Sample)",
    pdfUrl: "https://cors-blocked-link-example-for-fallback-triggers.pdf"
  },
  {
    id: "ep-1-da",
    workId: "digital-alchemy",
    episodeNumber: 1,
    title: "Ep 01: Ikatan Molekul Polimer Tinggi",
    pdfUrl: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf"
  }
];

export default function NexonShelf({ 
  userProfile, 
  onBackToPortal, 
  onAddNotification,
  currentUserId 
}: NexonShelfProps) {
  // Navigation views: "library" | "details" | "reader" | "admin"
  const [activeView, setActiveView] = useState<"library" | "details" | "reader" | "admin">("library");
  
  // Data State
  const [works, setWorks] = useState<NexonWork[]>([]);
  const [episodes, setEpisodes] = useState<NexonEpisode[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Selection state
  const [selectedWork, setSelectedWork] = useState<NexonWork | null>(null);
  const [selectedEpisode, setSelectedEpisode] = useState<NexonEpisode | null>(null);
  
  // Search & Filter
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTag, setSelectedTag] = useState<string>("All");

  // Password-based Admin Unlock System
  const [adminUnlocked, setAdminUnlocked] = useState(false);
  const isAdminMode = adminUnlocked;

  // Admin password states
  const [showAdminPasswordModal, setShowAdminPasswordModal] = useState(false);
  const [adminPasswordInput, setAdminPasswordInput] = useState("");
  const [adminPasswordError, setAdminPasswordError] = useState("");

  // Form State for Admin Panel
  const [newWorkTitle, setNewWorkTitle] = useState("");
  const [newWorkDesc, setNewWorkDesc] = useState("");
  const [newWorkAuthor, setNewWorkAuthor] = useState("");
  const [newWorkTags, setNewWorkTags] = useState("");
  const [newWorkStatus, setNewWorkStatus] = useState<"Ongoing" | "Completed">("Ongoing");
  const [newWorkCover, setNewWorkCover] = useState("");
  const [isUploadingCover, setIsUploadingCover] = useState(false);

  const [newEpWorkId, setNewEpWorkId] = useState("");
  const [newEpTitle, setNewEpTitle] = useState("");
  const [newEpNum, setNewEpNum] = useState<number | "">("");
  const [newEpPdf, setNewEpPdf] = useState("");
  const [isUploadingPdf, setIsUploadingPdf] = useState(false);

  // PDF.js Loaded flag
  const [pdfJsLoaded, setPdfJsLoaded] = useState(false);

  // Load Initial Data with Local Fallbacks
  useEffect(() => {
    async function initData() {
      setLoading(true);
      try {
        // 1. Fetch Works from Firestore
        const worksRef = collection(db, "nexonshelf_works");
        const worksSnap = await getDocs(worksRef).catch((error) => {
          handleFirestoreError(error, OperationType.LIST, "nexonshelf_works");
          throw error;
        });
        let loadedWorks: NexonWork[] = [];
        let loadedEpisodes: NexonEpisode[] = [];

        if (!worksSnap.empty) {
          worksSnap.forEach((docSnap) => {
            loadedWorks.push({ id: docSnap.id, ...docSnap.data() } as NexonWork);
          });

          // Fetch all episodes recursively/flatly
          for (const wk of loadedWorks) {
            const epRef = collection(db, `nexonshelf_works/${wk.id}/episodes`);
            const epSnap = await getDocs(epRef).catch((error) => {
              handleFirestoreError(error, OperationType.LIST, `nexonshelf_works/${wk.id}/episodes`);
              throw error;
            });
            epSnap.forEach((eSnap) => {
              loadedEpisodes.push({ id: eSnap.id, ...eSnap.data() } as NexonEpisode);
            });
          }
        }

        // If firestore is empty, utilize local storage or sample content
        const localWorks = localStorage.getItem("nexonshelf_local_works");
        const localEps = localStorage.getItem("nexonshelf_local_episodes");

        if (loadedWorks.length === 0) {
          if (localWorks) {
            loadedWorks = JSON.parse(localWorks);
          } else {
            loadedWorks = [...SAMPLE_WORKS];
            localStorage.setItem("nexonshelf_local_works", JSON.stringify(SAMPLE_WORKS));
          }
        } else {
          // Sync to localStorage as cache
          localStorage.setItem("nexonshelf_local_works", JSON.stringify(loadedWorks));
        }

        if (loadedEpisodes.length === 0) {
          if (localEps) {
            loadedEpisodes = JSON.parse(localEps);
          } else {
            loadedEpisodes = [...SAMPLE_EPISODES];
            localStorage.setItem("nexonshelf_local_episodes", JSON.stringify(SAMPLE_EPISODES));
          }
        } else {
          localStorage.setItem("nexonshelf_local_episodes", JSON.stringify(loadedEpisodes));
        }

        setWorks(loadedWorks);
        setEpisodes(loadedEpisodes);
      } catch (err) {
        console.warn("Failed retrieving from Firestore, loading robust offline simulation catalog:", err);
        // Load fallback storage safely
        const cachedWorks = localStorage.getItem("nexonshelf_local_works");
        const cachedEps = localStorage.getItem("nexonshelf_local_episodes");

        if (cachedWorks) {
          setWorks(JSON.parse(cachedWorks));
        } else {
          setWorks([...SAMPLE_WORKS]);
          localStorage.setItem("nexonshelf_local_works", JSON.stringify(SAMPLE_WORKS));
        }

        if (cachedEps) {
          setEpisodes(JSON.parse(cachedEps));
        } else {
          setEpisodes([...SAMPLE_EPISODES]);
          localStorage.setItem("nexonshelf_local_episodes", JSON.stringify(SAMPLE_EPISODES));
        }
      } finally {
        setLoading(false);
      }
    }

    initData();
  }, []);

  // Inject PDF.js Library Dynamically
  useEffect(() => {
    if (activeView === "reader" && !window.hasOwnProperty("pdfjsLib")) {
      const script = document.createElement("script");
      script.src = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js";
      script.async = true;
      script.onload = () => {
        // Setup worker
        const anyWindow = window as any;
        if (anyWindow.pdfjsLib) {
          anyWindow.pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js";
          setPdfJsLoaded(true);
        }
      };
      script.onerror = () => {
        console.error("Could not load PDFJS script from CDN.");
      };
      document.head.appendChild(script);
    } else if (window.hasOwnProperty("pdfjsLib")) {
      setPdfJsLoaded(true);
    }
  }, [activeView]);

  // Aggregate Tags
  const allTags = ["All", ...Array.from(new Set(works.flatMap(w => w.tags || []))) as string[]];

  // Filters the works catalog
  const filteredWorks = works.filter(w => {
    const matchesSearch = w.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          w.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          w.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTag = selectedTag === "All" || (w.tags && w.tags.includes(selectedTag));
    return matchesSearch && matchesTag;
  });

  // Handle Cover Art generation in-app based on comic id for high-fidelity styling
  const getCoverArt = (work: NexonWork) => {
    if (work.coverUrl) return work.coverUrl;
    
    // Fallback beautifully visually based on titles
    if (work.id.includes("chronicles")) {
      return "https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?auto=format&fit=crop&w=400&q=80"; // Tech digital grid neon
    }
    return "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=400&q=80"; // Glass digital creative art
  };

  // Upload Handlers
  const handleCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingCover(true);
    const reader = new FileReader();
    reader.onload = () => {
      setNewWorkCover(reader.result as string);
      setIsUploadingCover(false);
      onAddNotification("Sampul Diproses! 🎨", "Gambar thumbnail diunggah dan disimpan ke dalam database virtual.");
    };
    reader.onerror = () => {
      setIsUploadingCover(false);
      onAddNotification("Gagal Membaca File! ❌", "Sistem tidak dapat mengompresi gambar ini.");
    };
    reader.readAsDataURL(file);
  };

  const handlePdfUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== "application/pdf") {
      onAddNotification("Format Salah! ⚠️", "Harap unggah file dokumen berformat PDF.");
      return;
    }

    setIsUploadingPdf(true);
    const reader = new FileReader();
    reader.onload = () => {
      // In local fallback we store Base64 PDF directly which is fully portable!
      setNewEpPdf(reader.result as string);
      setIsUploadingPdf(false);
      onAddNotification("Dokumen Siap! 📂", `File PDF '${file.name}' siap dipasang di komik ini.`);
    };
    reader.onerror = () => {
      setIsUploadingPdf(false);
      onAddNotification("Failure reading PDF ❌", "Sistem gagal mengompres file PDF.");
    };
    reader.readAsDataURL(file);
  };

  // Add Work Admin Form Action
  const handleAddWork = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWorkTitle || !newWorkAuthor) {
      onAddNotification("Data Kosong! ⚠️", "Judul komik dan nama pembuat komik wajib diisi.");
      return;
    }

    const nextId = "nexon-" + Date.now();
    const parsedTags = newWorkTags.split(",").map(t => t.trim()).filter(Boolean);
    const fallbackImage = newWorkCover || "https://images.unsplash.com/photo-1618055155799-a3cdba836b8e?auto=format&fit=crop&w=400&q=80";

    const freshWork: NexonWork = {
      id: nextId,
      title: newWorkTitle,
      description: newWorkDesc || "Tidak ada deskripsi sinopsis komik.",
      author: newWorkAuthor,
      coverUrl: fallbackImage,
      tags: parsedTags.length > 0 ? parsedTags : ["Sci-Fi"],
      status: newWorkStatus,
      episodeCount: 0
    };

    try {
      // Add key value to Firestore
      const docRef = doc(db, "nexonshelf_works", nextId);
      await setDoc(docRef, freshWork).catch((error) => {
        handleFirestoreError(error, OperationType.WRITE, `nexonshelf_works/${nextId}`);
        throw error;
      });
    } catch (saveError) {
      console.warn("Firestore access denied. Saving locally...", saveError);
    }

    // Save to local hooks
    const updated = [freshWork, ...works];
    setWorks(updated);
    localStorage.setItem("nexonshelf_local_works", JSON.stringify(updated));

    onAddNotification("Karya Terbit! 🎉", `Komik '${newWorkTitle}' telah terdaftar di database NexonShelf.`);
    
    // Reset inputs
    setNewWorkTitle("");
    setNewWorkDesc("");
    setNewWorkAuthor("");
    setNewWorkTags("");
    setNewWorkCover("");
  };

  // Add Chapter/Episode Action
  const handleAddEpisode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEpWorkId || !newEpTitle || !newEpPdf) {
      onAddNotification("Harap Lengkapi! ⚠️", "Pilih Komik, tulis Judul Episode, dan pasangkan PDF/Dokumen cerita.");
      return;
    }

    let parsedEpNum = Number(newEpNum);
    if (!newEpNum || isNaN(parsedEpNum)) {
      // Auto-increment episode number
      const workEps = episodes.filter(ep => ep.workId === newEpWorkId);
      parsedEpNum = workEps.length > 0 ? Math.max(...workEps.map(e => e.episodeNumber)) + 1 : 1;
    }

    const epId = `ep-${parsedEpNum}-${newEpWorkId}`;
    const freshEp: NexonEpisode = {
      id: epId,
      workId: newEpWorkId,
      episodeNumber: parsedEpNum,
      title: `Ep ${parsedEpNum.toString().padStart(2, "0")}: ${newEpTitle}`,
      pdfUrl: newEpPdf
    };

    try {
      await setDoc(doc(db, `nexonshelf_works/${newEpWorkId}/episodes`, epId), freshEp).catch((error) => {
        handleFirestoreError(error, OperationType.WRITE, `nexonshelf_works/${newEpWorkId}/episodes/${epId}`);
        throw error;
      });
    } catch (saveError) {
      console.warn("Firestore integration rejected profile rule setup, storing to Local Instance:", saveError);
    }

    // Store inside state
    const newEpsArr = [freshEp, ...episodes].sort((a, b) => a.episodeNumber - b.episodeNumber);
    setEpisodes(newEpsArr);
    localStorage.setItem("nexonshelf_local_episodes", JSON.stringify(newEpsArr));

    // Update work episode counter
    const updatedWorks = works.map(w => {
      if (w.id === newEpWorkId) {
        const revisedWork = { ...w, episodeCount: w.episodeCount + 1 };
        // Sync parent to Firestore too
        setDoc(doc(db, "nexonshelf_works", w.id), revisedWork).catch((error) => {
          handleFirestoreError(error, OperationType.WRITE, `nexonshelf_works/${w.id}`);
        });
        return revisedWork;
      }
      return w;
    });

    setWorks(updatedWorks);
    localStorage.setItem("nexonshelf_local_works", JSON.stringify(updatedWorks));

    onAddNotification("Episode Ditambahkan! 🚀", `Karya '${newEpTitle}' siap diakses para pembaca.`);

    // Reset fields
    setNewEpTitle("");
    setNewEpNum("");
    setNewEpPdf("");
  };

  // Delete Comic Book Title
  const handleDeleteWork = async (workId: string) => {
    if (!window.confirm("Apakah Anda yakin ingin menghapus seluruh karya komik ini beserta semua episodenya?")) return;

    try {
      await deleteDoc(doc(db, "nexonshelf_works", workId)).catch((error) => {
        handleFirestoreError(error, OperationType.DELETE, `nexonshelf_works/${workId}`);
        throw error;
      });
    } catch (err) {
      console.warn("Offline action triggered:", err);
    }

    const filteredW = works.filter(w => w.id !== workId);
    const filteredEp = episodes.filter(ep => ep.workId !== workId);

    setWorks(filteredW);
    setEpisodes(filteredEp);

    localStorage.setItem("nexonshelf_local_works", JSON.stringify(filteredW));
    localStorage.setItem("nexonshelf_local_episodes", JSON.stringify(filteredEp));

    onAddNotification("Karya Berhasil Dihapus 🗑️", "Detail karya telah dilepaskan dari server.");
  };

  return (
    <div className="flex-1 bg-[#080a10] text-[#cfd3ee] flex flex-col font-sans relative overflow-hidden" id="nexonshelf_container">
      {/* Decorative matrix cyberpunk background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-900/15 via-[#080a11] to-[#040508] pointer-events-none -z-10"></div>
      
      {/* SubHead / Navigation */}
      <header className="h-14 bg-[#0a0d17]/80 backdrop-blur-md border-b border-blue-500/10 px-4 md:px-6 flex items-center justify-between shrink-0 top-0 sticky z-30">
        <div className="flex items-center gap-2 md:gap-3">
          <button
            onClick={() => {
              if (activeView === "reader") {
                setActiveView("details");
              } else if (activeView === "details" || activeView === "admin") {
                setActiveView("library");
              } else {
                onBackToPortal();
              }
            }}
            className="p-1.5 hover:bg-white/5 text-blue-400 rounded-xl cursor-pointer transition-colors"
            title="Kembali"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="flex items-baseline gap-2">
            <h1 className="text-sm font-black tracking-widest text-[#ecefff] font-mono select-none block">
              NEXON<span className="text-blue-500">SHELF</span>
            </h1>
            <span className="text-[9px] bg-blue-500/15 font-mono text-blue-400 px-1.5 py-0.5 rounded-md font-bold uppercase tracking-widest hidden sm:inline-block">DIGITAL READER</span>
          </div>
        </div>

        {/* Action Controls (Tab Switch/Simulator) */}
        <div className="flex items-center gap-2">
          {/* Status Indicator */}
          <div className="flex items-center gap-1 bg-blue-950/40 border border-blue-500/10 rounded-xl px-2.5 py-1.5 text-[10px] sm:text-xs">
            <span className="text-white/40 hidden xs:inline font-mono">Status:</span>
            <span className={`font-bold uppercase tracking-wider ${isAdminMode ? 'text-cyan-400' : 'text-slate-400'}`}>
              {isAdminMode ? '👑 ADMIN' : '👤 VIEW ONLY'}
            </span>
          </div>

          {/* Admin Log In Button */}
          {!isAdminMode && (
            <button
              onClick={() => {
                setAdminPasswordInput("");
                setAdminPasswordError("");
                setShowAdminPasswordModal(true);
              }}
              className="py-1.5 px-3 bg-blue-900/40 hover:bg-blue-800/60 text-blue-300 hover:text-white text-[10px] sm:text-xs font-bold font-mono rounded-xl border border-blue-500/20 transition-all cursor-pointer flex items-center gap-1"
              title="Masuk sebagai Admin"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>ADMIN</span>
            </button>
          )}

          {/* Quick Add Work Button shortcut */}
          {isAdminMode && activeView === "library" && (
            <button
              onClick={() => setActiveView("admin")}
              className="py-1.5 px-3 bg-blue-600 hover:bg-blue-550 active:scale-95 text-white text-[10px] sm:text-xs font-bold font-mono rounded-xl transition-all cursor-pointer flex items-center gap-1 hover:shadow-[0_0_15px_rgba(37,99,235,0.4)]"
            >
              <Plus className="w-3.5 h-3.5 shrink-0" />
              <span className="hidden sm:inline">TAMBAH KARYA</span>
            </button>
          )}

          {/* Admin Home Toggle */}
          {isAdminMode && (
            <button
              onClick={() => setActiveView(activeView === "admin" ? "library" : "admin")}
              className={`p-1.5 rounded-xl border cursor-pointer transition-all ${
                activeView === "admin" 
                  ? "bg-purple-500/20 border-purple-500/40 text-purple-300"
                  : "bg-blue-900/10 border-blue-500/10 text-blue-400 hover:bg-blue-900/20"
              }`}
              title="Panel Kelola Admin"
            >
              <Settings className="w-4.5 h-4.5" />
            </button>
          )}

          {/* Admin Logout / Lock Button */}
          {isAdminMode && (
            <button
              onClick={() => {
                setAdminUnlocked(false);
                setActiveView("library");
                onAddNotification("Admin Terkunci! 🔒", "Anda telah keluar dari akses admin.");
              }}
              className="p-1.5 bg-red-950/20 hover:bg-red-900/30 text-red-400 rounded-xl border border-red-500/20 cursor-pointer transition-all"
              title="Keluar Akses Admin"
            >
              <Unlock className="w-4.5 h-4.5 text-cyan-400" />
            </button>
          )}
        </div>
      </header>

      {/* Primary Scroll Content Area */}
      <div className="flex-1 overflow-y-auto" id="nexonshelf_main_stage">
        
        {/* --- VIEW 1: LIBRARY / CATALOG --- */}
        {activeView === "library" && (
          <div className="max-w-5xl mx-auto px-4 py-6 md:py-10 space-y-8 animate-fadeIn">
            {/* Hero Brand Title */}
            <div className="p-6 md:p-8 rounded-3xl bg-gradient-to-r from-blue-950/40 to-slate-950/40 border border-blue-500/10 relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
              <div className="absolute top-0 right-0 w-64 h-64 bg-blue-505/5 rounded-full blur-3xl pointer-events-none"></div>
              <div className="space-y-2 md:max-w-xl text-center md:text-left">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[9px] font-bold bg-blue-500/15 text-blue-400 border border-blue-500/30 font-mono tracking-widest uppercase">
                  ✨ MULTIPLATFORM COMIC TERMINAL
                </span>
                <h2 className="text-xl md:text-2xl font-extrabold text-white tracking-tight">
                  Sambut Era Baca <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-300 to-pink-300 font-display">Nexon Shelf</span>
                </h2>
                <p className="text-white/60 text-[11px] sm:text-xs leading-relaxed">
                  Pusat komik & cerita interaktif digital Nusantara. Nikmati baca komik tanpa batas secara lancar dengan layout scroll modern dan navigasi tak tertandingi gratis di genggaman Anda.
                </p>
              </div>
              <div className="shrink-0 flex items-center justify-center p-3 bg-blue-500/15 rounded-2xl border border-blue-500/20 shadow-inner">
                <BookOpen className="w-10 h-10 text-blue-400 animate-pulse" />
              </div>
            </div>

            {/* Shelf Filter Grid */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-white/5 pb-4">
              {/* Tag Badges */}
              <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-2 sm:pb-0 scrollbar-none">
                {allTags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setSelectedTag(tag)}
                    className={`py-1 px-3 text-[10px] sm:text-xs font-bold font-mono tracking-wider rounded-lg transition-all cursor-pointer border ${
                      selectedTag === tag
                        ? "bg-blue-600 text-white border-blue-500 shadow-[0_0_10px_rgba(37,99,235,0.3)]"
                        : "bg-[#0d1017]/80 text-[#8f96bd] border-white/5 hover:bg-[#121622]/80 hover:text-white"
                    }`}
                  >
                    {tag.toUpperCase()}
                  </button>
                ))}
              </div>

              {/* Live Search */}
              <div className="relative w-full sm:w-64 shrink-0">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-blue-400/50" />
                <input
                  type="text"
                  placeholder="Cari komik, penulis..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-[#0d111b] border border-blue-500/15 focus:border-blue-400/55 rounded-xl text-xs pl-9 pr-4 py-2 text-white placeholder-blue-300/35 focus:outline-none transition-all focus:ring-1 focus:ring-blue-450"
                />
              </div>
            </div>

            {/* Loading Grid */}
            {loading ? (
              <div className="text-center py-20 flex flex-col items-center justify-center gap-3">
                <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
                <p className="text-xs font-mono tracking-wider text-blue-300">Menghubungkan ke Rak Komik Nexon...</p>
              </div>
            ) : filteredWorks.length === 0 ? (
              <div className="text-center py-20 border border-dashed border-white/5 rounded-3xl p-6">
                <ShieldAlert className="w-10 h-10 text-white/20 mx-auto mb-3" />
                <h3 className="text-sm font-bold text-white mb-1">Katalog Masih Kosong</h3>
                <p className="text-xs text-white/40 max-w-sm mx-auto leading-relaxed">
                  Tidak ada komik yang sesuai dengan pencarian Anda. {isAdminMode ? "Silakan tambahkan baru lewat panel kelola admin di pojok atas!" : ""}
                </p>
                {isAdminMode && (
                  <button
                    onClick={() => setActiveView("admin")}
                    className="mt-4 px-3 py-1.5 bg-blue-600/20 hover:bg-blue-600/35 border border-blue-500/20 rounded-xl text-xs font-bold text-blue-300 transition-all cursor-pointer font-mono"
                  >
                    TAMBAH KARYA PERTAMA
                  </button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6" id="nexonshelf_library_grid">
                {filteredWorks.map((work) => {
                  const workEps = episodes.filter(e => e.workId === work.id);
                  const epCount = workEps.length;

                  return (
                    <div
                      key={work.id}
                      onClick={() => {
                        setSelectedWork(work);
                        setActiveView("details");
                      }}
                      className="group bg-[#0c0e18] hover:bg-[#121526] border border-blue-900/20 hover:border-blue-500/40 rounded-2xl p-3 relative flex flex-col justify-between transition-all duration-300 cursor-pointer shadow-lg transform hover:-translate-y-1.5 hover:shadow-[0_0_20px_rgba(59,130,246,0.15)]"
                    >
                      <div className="space-y-3">
                        {/* cover wrap */}
                        <div className="aspect-[3/4] w-full rounded-xl overflow-hidden relative bg-slate-900 border border-white/5">
                          <img
                            src={getCoverArt(work)}
                            alt={work.title}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover group-hover:scale-105 transition-all duration-500"
                          />
                          {/* badges overlay */}
                          <div className="absolute top-2 left-2 right-2 flex items-center justify-between gap-1">
                            <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded uppercase tracking-wider backdrop-blur-md border ${
                              work.status === "Completed" 
                                ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/20" 
                                : "bg-blue-600/20 text-blue-300 border-blue-500/20"
                            }`}>
                              {work.status}
                            </span>
                            <span className="text-[8px] font-mono font-bold px-1.5 py-0.5 rounded uppercase tracking-widest bg-[#0a0d17]/85 text-indigo-300 backdrop-blur-sm border border-purple-500/20">
                              {epCount} EPISODE
                            </span>
                          </div>
                        </div>

                        {/* info */}
                        <div className="space-y-1">
                          <h3 className="font-bold text-xs sm:text-sm text-white group-hover:text-blue-400 transition-colors line-clamp-1">
                            {work.title}
                          </h3>
                          <span className="text-[10px] text-white/50 block line-clamp-1">
                            Oleh: {work.author}
                          </span>
                        </div>
                      </div>

                      {/* footer inside card */}
                      <div className="mt-4 pt-2.5 border-t border-white/5 flex items-center justify-between text-[9px] font-bold font-mono tracking-wider text-blue-400">
                        <span>DETAIL KARYA</span>
                        <span className="group-hover:translate-x-1 transition-transform font-sans font-black">&rarr;</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* --- VIEW 2: WORK DETAILED CHAPTERS --- */}
        {activeView === "details" && selectedWork && (
          <div className="max-w-4xl mx-auto px-4 py-6 md:py-10 space-y-8 animate-fadeIn">
            {/* Header / Nav Back */}
            <button
              onClick={() => setActiveView("library")}
              className="text-xs font-bold font-mono text-blue-400 hover:text-blue-300 cursor-pointer flex items-center gap-1.5"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>KEMBALI KE RAK BUKU</span>
            </button>

            {/* Immersive Parallax Header Panel */}
            <div className="bg-[#0b0e1a]/80 border border-blue-500/20 rounded-3xl p-6 md:p-8 flex flex-col md:flex-row gap-6 md:gap-8 shadow-2xl relative overflow-hidden backdrop-blur-md">
              {/* Blur glow */}
              <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-indigo-505/10 rounded-full blur-3xl pointer-events-none"></div>
              
              {/* Book cover projection */}
              <div className="w-40 sm:w-48 mx-auto md:mx-0 shrink-0 aspect-[3/4] rounded-2xl overflow-hidden shadow-[0_15px_30px_rgba(0,0,0,0.5)] border border-blue-500/10">
                <img
                  src={getCoverArt(selectedWork)}
                  alt={selectedWork.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Book metadata information area */}
              <div className="flex-1 space-y-4 flex flex-col justify-between text-center md:text-left">
                <div className="space-y-2">
                  <div className="flex flex-wrap items-center justify-center md:justify-start gap-1.5">
                    {selectedWork.tags.map((tag) => (
                      <span key={tag} className="text-[9px] bg-blue-500/10 text-blue-300 font-mono font-bold px-2 py-0.5 rounded-md border border-blue-500/20">
                        {tag.toUpperCase()}
                      </span>
                    ))}
                    <span className={`text-[9px] px-2 py-0.5 font-bold font-mono rounded-md uppercase border ${
                      selectedWork.status === "Completed" 
                        ? "bg-emerald-500/10 text-emerald-300 border-emerald-500/20" 
                        : "bg-amber-500/10 text-amber-300 border-amber-500/25"
                    }`}>
                      {selectedWork.status}
                    </span>
                  </div>

                  <h2 className="text-lg md:text-2xl font-extrabold text-white leading-tight">
                    {selectedWork.title}
                  </h2>
                  <p className="text-xs text-white/50">
                    Karya Eksklusif: <strong className="text-[#cfd3ee]">{selectedWork.author}</strong>
                  </p>
                </div>

                <div className="py-3 px-4 rounded-2xl bg-white/5 border border-white/5 text-left">
                  <span className="block text-[10px] font-extrabold tracking-wider text-blue-400 font-mono uppercase mb-1">Sinopsis Utama</span>
                  <p className="text-white/70 text-[11px] sm:text-xs leading-relaxed font-sans font-light">
                    {selectedWork.description}
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                  {/* Total available eps */}
                  <div className="text-xs font-mono text-white/55">
                    Total: <strong className="text-white font-bold">{episodes.filter(e => e.workId === selectedWork.id).length} Episode</strong> Terbit
                  </div>
                </div>
              </div>
            </div>

            {/* Episodes List Grid */}
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-white/5 pb-2">
                <h3 className="text-sm font-bold text-white tracking-widest font-mono uppercase flex items-center gap-2">
                  <Layers className="w-4 h-4 text-blue-500" />
                  DAFTAR EPISODE TERSEDIA
                </h3>
                {isAdminMode && (
                  <button
                    onClick={() => {
                      setNewEpWorkId(selectedWork.id);
                      setActiveView("admin");
                    }}
                    className="text-[10px] sm:text-xs font-bold font-mono text-purple-400 hover:text-purple-300 cursor-pointer flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    TAMBAH EPISODE BARU
                  </button>
                )}
              </div>

              {episodes.filter(e => e.workId === selectedWork.id).length === 0 ? (
                <div className="text-center py-12 p-6 border border-dashed border-white/5 rounded-2xl">
                  <AlertCircle className="w-8 h-8 text-white/30 mx-auto mb-2" />
                  <p className="text-xs text-white/40">Belum ada episode diunggah untuk komik ini.</p>
                  {isAdminMode && (
                    <button
                      onClick={() => {
                        setNewEpWorkId(selectedWork.id);
                        setActiveView("admin");
                      }}
                      className="mt-3 py-1 px-3 bg-indigo-650 hover:bg-indigo-600 text-[11px] font-bold font-mono rounded-lg transition-all text-white cursor-pointer"
                    >
                      Unggah Episode Perdana
                    </button>
                  )}
                </div>
              ) : (
                <div className="grid gap-3" id="nexonshelf_episodes_stack">
                  {episodes
                    .filter(e => e.workId === selectedWork.id)
                    .sort((a, b) => a.episodeNumber - b.episodeNumber)
                    .map((ep, idx) => (
                      <div
                        key={ep.id}
                        onClick={() => {
                          setSelectedEpisode(ep);
                          setActiveView("reader");
                        }}
                        className="group flex items-center justify-between bg-[#0d101e] hover:bg-blue-900/10 border border-blue-900/30 hover:border-blue-500/35 p-3.5 rounded-2xl cursor-pointer transition-all duration-200 transform hover:scale-101"
                      >
                        <div className="flex items-center gap-3.5">
                          {/* Num circle */}
                          <div className="w-8 h-8 rounded-lg bg-blue-950 text-blue-450 border border-blue-500/10 flex items-center justify-center font-black font-mono text-xs group-hover:bg-blue-500 group-hover:text-white transition-all">
                            {ep.episodeNumber.toString().padStart(2, "0")}
                          </div>
                          <div>
                            <h4 className="text-xs sm:text-sm font-bold text-white group-hover:text-blue-400 transition-colors">
                              {ep.title}
                            </h4>
                            <span className="text-[10px] text-white/40 font-mono tracking-wide">Digital PDF Scrollable Page Document</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-3.5">
                          <button
                            type="button"
                            className="py-1 px-3 bg-blue-600/10 group-hover:bg-blue-600 text-blue-400 group-hover:text-white text-[10px] font-bold font-mono rounded-xl transition-all border border-blue-502/20 shrink-0"
                          >
                            BACA SEKARANG
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* --- VIEW 3: SCROLL READER VIEW --- */}
        {activeView === "reader" && selectedEpisode && selectedWork && (
          <NexonScrollReader
            episode={selectedEpisode}
            work={selectedWork}
            allEpisodes={episodes.filter(e => e.workId === selectedWork.id).sort((a,b)=>a.episodeNumber-b.episodeNumber)}
            pdfJsLoaded={pdfJsLoaded}
            onBack={() => setActiveView("details")}
            onSwitchEpisode={(nextEp) => setSelectedEpisode(nextEp)}
            onAddNotification={onAddNotification}
          />
        )}

        {/* --- VIEW 4: ADMIN CONTROL PANEL --- */}
        {activeView === "admin" && (
          <div className="max-w-4xl mx-auto px-4 py-6 md:py-10 space-y-8 animate-fadeIn">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div>
                <span className="inline-block text-[9px] bg-purple-500/15 text-purple-400 px-2 py-0.5 rounded-md font-bold font-mono mb-1 tracking-widest uppercase">
                  🔑 SYSTEM CONSOLE
                </span>
                <h2 className="text-xl font-extrabold text-white">Dashboard Kelola NexonShelf</h2>
              </div>
              <button
                onClick={() => setActiveView("library")}
                className="text-xs font-bold font-mono text-slate-400 hover:text-white cursor-pointer"
              >
                TUTUP DASHBOARD
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Form 1: Add Comic Book Card */}
              <div className="bg-[#0b0d17] border border-blue-900/30 p-5 rounded-3xl space-y-4 shadow-xl">
                <div className="flex items-center gap-2 text-blue-400 border-b border-white/5 pb-2">
                  <Bookmark className="w-4.5 h-4.5" />
                  <span className="text-xs font-bold font-mono tracking-wider uppercase">Terbitkan Judul Komik Baru</span>
                </div>

                <form onSubmit={handleAddWork} className="space-y-4 text-xs">
                  <div className="space-y-1">
                    <label className="block text-[10px] uppercase text-white/50 font-bold font-mono">Judul Komik / Karya</label>
                    <input
                      type="text"
                      required
                      placeholder="Contoh: Nexon Chronicles: Volume II"
                      value={newWorkTitle}
                      onChange={(e) => setNewWorkTitle(e.target.value)}
                      className="w-full bg-[#111422] border border-white/5 focus:border-blue-550 rounded-xl px-3 py-2 text-white outline-none font-sans"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-[10px] uppercase text-white/50 font-bold font-mono">Penulis / Creator</label>
                    <input
                      type="text"
                      required
                      placeholder="Contoh: Zacky Akira"
                      value={newWorkAuthor}
                      onChange={(e) => setNewWorkAuthor(e.target.value)}
                      className="w-full bg-[#111422] border border-white/5 focus:border-blue-550 rounded-xl px-3 py-2 text-white outline-none font-sans"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-[10px] uppercase text-white/50 font-bold font-mono">Sinopsis / Deskripsi Ringkas</label>
                    <textarea
                      placeholder="Tuliskan latar belakang, sinopsis komik, rincian cerita..."
                      rows={3}
                      value={newWorkDesc}
                      onChange={(e) => setNewWorkDesc(e.target.value)}
                      className="w-full bg-[#111422] border border-white/5 focus:border-blue-550 rounded-xl px-3 py-2 text-white outline-none font-sans leading-relaxed"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="block text-[10px] uppercase text-white/50 font-bold font-mono">Tags (Pisah Koma)</label>
                      <input
                        type="text"
                        placeholder="Contoh: Sci-Fi, Coding, Action"
                        value={newWorkTags}
                        onChange={(e) => setNewWorkTags(e.target.value)}
                        className="w-full bg-[#111422] border border-white/5 focus:border-blue-550 rounded-xl px-3 py-2 text-white outline-none font-sans"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[10px] uppercase text-white/50 font-bold font-mono">Status Proyek</label>
                      <select
                        value={newWorkStatus}
                        onChange={(e) => setNewWorkStatus(e.target.value as any)}
                        className="w-full bg-[#111422] border border-white/5 focus:border-blue-550 rounded-xl px-3 py-2 text-white outline-none font-mono font-bold"
                      >
                        <option value="Ongoing">ONGOING</option>
                        <option value="Completed">COMPLETED</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2 pt-2">
                    <label className="block text-[10px] uppercase text-white/50 font-bold font-mono">Kustom Cover Art</label>
                    <div className="flex items-center gap-3">
                      {newWorkCover ? (
                        <div className="w-14 h-18 rounded-lg overflow-hidden border border-white/15 shrink-0 bg-slate-900 relative group">
                          <img src={newWorkCover} alt="Cover Preview" className="w-full h-full object-cover" />
                          <button
                            type="button"
                            onClick={() => setNewWorkCover("")}
                            className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center text-red-400 font-bold active:scale-90 transition-all font-mono"
                          >
                            BATAL
                          </button>
                        </div>
                      ) : (
                        <div className="flex-1">
                          <label className="flex flex-col items-center justify-center p-3.5 bg-blue-950/20 border border-dashed border-blue-500/20 hover:border-blue-400 rounded-2xl cursor-pointer text-center text-[11px] text-blue-300 transition-colors">
                            <UploadCloud className="w-5 h-5 mb-1.5 text-blue-400" />
                            {isUploadingCover ? "Memproses gambar..." : "Pilih File Sampul (*.png/jpg)"}
                            <input
                              type="file"
                              accept="image/*"
                              onChange={handleCoverUpload}
                              className="hidden"
                              disabled={isUploadingCover}
                            />
                          </label>
                        </div>
                      )}
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-blue-600 hover:bg-blue-550 text-white font-bold font-mono rounded-xl cursor-pointer transition-colors mt-2"
                  >
                    TERBITKAN KOMIK BARU
                  </button>
                </form>
              </div>

              {/* Form 2: Add Episode Details */}
              <div className="bg-[#0b0d17] border border-blue-900/30 p-5 rounded-3xl space-y-4 shadow-xl">
                <div className="flex items-center gap-2 text-purple-400 border-b border-white/5 pb-2">
                  <Layers className="w-4.5 h-4.5" />
                  <span className="text-xs font-bold font-mono tracking-wider uppercase">Unggah File Episode Baru</span>
                </div>

                <form onSubmit={handleAddEpisode} className="space-y-4 text-xs">
                  <div className="space-y-1">
                    <label className="block text-[10px] uppercase text-white/50 font-bold font-mono">Pilih Karya Komik</label>
                    <select
                      value={newEpWorkId}
                      onChange={(e) => setNewEpWorkId(e.target.value)}
                      required
                      className="w-full bg-[#111422] border border-white/5 focus:border-blue-550 rounded-xl px-3 py-2 text-white outline-none font-bold"
                    >
                      <option value="">-- Pilih Judul Buku --</option>
                      {works.map(w => (
                        <option key={w.id} value={w.id}>{w.title}</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div className="col-span-2 space-y-1">
                      <label className="block text-[10px] uppercase text-white/50 font-bold font-mono">Judul Bab / Episode</label>
                      <input
                        type="text"
                        required
                        placeholder="Contoh: Compiler Semesta"
                        value={newEpTitle}
                        onChange={(e) => setNewEpTitle(e.target.value)}
                        className="w-full bg-[#111422] border border-white/5 focus:border-blue-550 rounded-xl px-3 py-2 text-white outline-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[10px] uppercase text-white/50 font-bold font-mono">No. Ep (Opsional)</label>
                      <input
                        type="number"
                        placeholder="Auto"
                        value={newEpNum}
                        onChange={(e) => setNewEpNum(e.target.value ? Number(e.target.value) : "")}
                        className="w-full bg-[#111422] border border-white/5 focus:border-blue-550 rounded-xl px-3 py-2 text-white outline-none font-mono"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="block text-[10px] uppercase text-white/50 font-bold font-mono">File PDF Komik / Cerita</label>
                    
                    {/* Choose between URL or manual base64 file */}
                    <div className="grid grid-cols-1 gap-2.5">
                      <input
                        type="text"
                        placeholder="Tempel Dokumen PDF URL (Contoh: https://.../comic.pdf)"
                        value={newEpPdf.startsWith("data:") ? "" : newEpPdf}
                        onChange={(e) => setNewEpPdf(e.target.value)}
                        className="w-full bg-[#111422] border border-white/5 focus:border-blue-550 rounded-xl px-3 py-2 text-white outline-none text-xs font-mono"
                      />

                      <div className="text-center text-[10px] text-white/20 uppercase tracking-widest font-mono">atau</div>

                      {newEpPdf.startsWith("data:") ? (
                        <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center justify-between">
                          <span className="text-[10px] text-emerald-400 font-mono font-bold">PDF BERGABUNG DI INTEGRASI LOKAL</span>
                          <button
                            type="button"
                            onClick={() => setNewEpPdf("")}
                            className="text-[9px] text-[#ff8080] font-mono hover:underline cursor-pointer"
                          >
                            HAPUS PDF
                          </button>
                        </div>
                      ) : (
                        <label className="flex flex-col items-center justify-center p-4 bg-purple-950/20 border border-dashed border-purple-500/20 hover:border-purple-400 rounded-2xl cursor-pointer text-center text-[11px] text-purple-300 transition-colors">
                          <UploadCloud className="w-5 h-5 mb-1.5 text-purple-400" />
                          {isUploadingPdf ? "Mempersiapkan dokumen..." : "Unggah & Kompres File PDF Lokal"}
                          <input
                            type="file"
                            accept="application/pdf"
                            onChange={handlePdfUpload}
                            className="hidden"
                            disabled={isUploadingPdf}
                          />
                        </label>
                      )}
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-purple-600 hover:bg-purple-550 text-white font-bold font-mono rounded-xl cursor-pointer transition-colors mt-2"
                  >
                    UNGKAP EPISODE KE PORTAL
                  </button>
                </form>
              </div>
            </div>

            {/* List Table of Works currently in Rak */}
            <div className="space-y-3 pt-4">
              <h3 className="text-xs font-bold text-white tracking-wider font-mono uppercase">Administrasi & Pencopotan Komik</h3>
              <div className="bg-[#0b0e1b] border border-blue-900/15 overflow-hidden rounded-2xl">
                <table className="w-full text-[11px] border-collapse text-left">
                  <thead>
                    <tr className="bg-blue-950/20 border-b border-white/5 font-bold font-mono text-white/40">
                      <th className="p-3">JUDUL KARYA</th>
                      <th className="p-3 hidden sm:table-cell">PENULIS</th>
                      <th className="p-3">EPISODE</th>
                      <th className="p-3 text-right">AKSI</th>
                    </tr>
                  </thead>
                  <tbody>
                    {works.map((wk) => (
                      <tr key={wk.id} className="border-b border-white/5 hover:bg-[#111424]">
                        <td className="p-3 font-semibold text-white">{wk.title}</td>
                        <td className="p-3 text-white/55 hidden sm:table-cell">{wk.author}</td>
                        <td className="p-3 font-mono font-bold text-blue-400">
                          {episodes.filter(e => e.workId === wk.id).length} EP
                        </td>
                        <td className="p-3 text-right">
                          <button
                            onClick={() => handleDeleteWork(wk.id)}
                            className="p-1.5 hover:bg-red-500/10 text-red-400 hover:text-red-300 rounded-md cursor-pointer transition-colors"
                            title="Hapus Karya"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* --- PASSWORD MODAL FOR ADMIN LOCK --- */}
      {showAdminPasswordModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn" id="nexonshelf_pwd_modal_overlay">
          <div className="bg-[#0e111a] border border-blue-500/25 p-6 sm:p-8 rounded-3xl w-full max-w-md space-y-5 shadow-2xl relative overflow-hidden animate-scaleIn">
            {/* Ambient accent inside modal */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl pointer-events-none"></div>
            
            <div className="text-center space-y-2">
              <div className="w-12 h-12 bg-blue-500/10 rounded-2xl border border-blue-500/20 flex items-center justify-center text-blue-400 mx-auto shadow-inner">
                <Lock className="w-6 h-6" />
              </div>
              <h3 className="text-base sm:text-lg font-black text-white tracking-tight font-sans">Kunci Pengelola NexonShelf</h3>
              <p className="text-[11px] text-[#8f96bd] leading-relaxed">
                Silakan masukkan kata sandi pengelola untuk mengaktifkan persetujuan unggah, kustomisasi metadata, dan penambahan episode.
              </p>
            </div>

            {adminPasswordError && (
              <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-2 text-xs text-red-400 font-mono">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{adminPasswordError}</span>
              </div>
            )}

            <form onSubmit={(e) => {
              e.preventDefault();
              if (adminPasswordInput === "adminotakunee27ttrt5yyi") {
                setAdminUnlocked(true);
                setShowAdminPasswordModal(false);
                setAdminPasswordInput("");
                setAdminPasswordError("");
                setActiveView("admin");
                onAddNotification("Admin Aktif! 👑", "Anda telah sukses masuk sebagai pengelola NexonShelf.");
              } else {
                setAdminPasswordError("Kata sandi salah. Silakan coba kembali.");
              }
            }} className="space-y-4">
              <div className="space-y-1.5 text-left">
                <label className="block text-[10px] font-bold text-white/50 uppercase tracking-widest font-mono">SANDI OTORISASI</label>
                <div className="relative">
                  <input
                    type="password"
                    placeholder="Sandi Admin"
                    value={adminPasswordInput}
                    onChange={(e) => setAdminPasswordInput(e.target.value)}
                    className="w-full bg-[#07090f] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-white/20 focus:border-blue-500/50 outline-none font-mono"
                    required
                    autoFocus
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowAdminPasswordModal(false);
                    setAdminPasswordInput("");
                    setAdminPasswordError("");
                  }}
                  className="py-2.5 px-3 bg-white/5 hover:bg-white/10 border border-white/5 text-xs text-white/70 hover:text-white rounded-xl transition-all cursor-pointer font-mono font-bold"
                >
                  BATAL
                </button>
                <button
                  type="submit"
                  className="py-2.5 px-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-550 hover:to-indigo-550 text-white text-xs font-bold font-mono rounded-xl transition-all cursor-pointer shadow-lg shadow-blue-500/15"
                >
                  VERIFIKASI
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}

// -------------------------------------------------------------
// CONTINUOUS SCROLL READER COMPONENT (Dynamic script PDF.js)
// -------------------------------------------------------------
interface NexonScrollReaderProps {
  episode: NexonEpisode;
  work: NexonWork;
  allEpisodes: NexonEpisode[];
  pdfJsLoaded: boolean;
  onBack: () => void;
  onSwitchEpisode: (nextEp: NexonEpisode) => void;
  onAddNotification: (title: string, msg: string) => void;
}

function NexonScrollReader({
  episode,
  work,
  allEpisodes,
  pdfJsLoaded,
  onBack,
  onSwitchEpisode,
  onAddNotification
}: NexonScrollReaderProps) {
  const [zoom, setZoom] = useState(100); // Zoom level %
  const [loadingPdf, setLoadingPdf] = useState(true);
  const [pdfPages, setPdfPages] = useState<string[]>([]); // Dynamic pages representation
  const [isCorsTriggered, setIsCorsTriggered] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Pagination index checks
  const currIndex = allEpisodes.findIndex(e => e.id === episode.id);
  const prevEpisode = currIndex > 0 ? allEpisodes[currIndex - 1] : null;
  const nextEpisode = currIndex < allEpisodes.length - 1 ? allEpisodes[currIndex + 1] : null;

  // Load PDF content
  useEffect(() => {
    let active = true;
    async function renderPdfDocument() {
      setLoadingPdf(true);
      setIsCorsTriggered(false);
      setPdfPages([]);

      const canvasContainer = document.getElementById("pdf_renderer_stack");
      if (canvasContainer) {
        canvasContainer.innerHTML = "";
      }

      // Check if this is an offline Base64 PDF file or dynamic dummy simulator trigger
      if (episode.pdfUrl.startsWith("data:application/pdf;base64,")) {
        try {
          if (!pdfJsLoaded) return;
          const anyWindow = window as any;
          const pdfjsLib = anyWindow.pdfjsLib;
          if (!pdfjsLib) throw new Error("PDFJS Library missing");

          // Convert base64 to typed array
          const base64Content = episode.pdfUrl.split(",")[1];
          const rawBinary = window.atob(base64Content);
          const rawLength = rawBinary.length;
          const array = new Uint8Array(new ArrayBuffer(rawLength));
          for (let i = 0; i < rawLength; i++) {
            array[i] = rawBinary.charCodeAt(i);
          }

          const loadingTask = pdfjsLib.getDocument({ data: array });
          const pdf = await loadingTask.promise;
          
          if (!active) return;
          await renderAllPages(pdf);
          setLoadingPdf(false);
          return;
        } catch (b64Error) {
          console.error("Failed to render Base64 PDF directly:", b64Error);
          setIsCorsTriggered(true);
          setLoadingPdf(false);
          return;
        }
      }

      // Handle standard loading from external URL
      try {
        if (!pdfJsLoaded) {
          // Wait 2 seconds for dynamic load
          await new Promise(resolve => setTimeout(resolve, 1500));
        }

        const anyWindow = window as any;
        const pdfjsLib = anyWindow.pdfjsLib;

        if (!pdfjsLib) {
          throw new Error("Sistem PDFJS tidak siap.");
        }

        // Apply our API proxy to bypass CORS restrictions
        let targetUrl = episode.pdfUrl;
        if (targetUrl.startsWith("http://") || targetUrl.startsWith("https://")) {
          targetUrl = `/api/proxy-pdf?url=${encodeURIComponent(targetUrl)}`;
        }

        // Fetch PDF through CORS proxy
        const loadingTask = pdfjsLib.getDocument({
          url: targetUrl,
          withCredentials: false
        });

        const pdf = await loadingTask.promise;
        if (!active) return;

        await renderAllPages(pdf);
        setLoadingPdf(false);
      } catch (corsErr: any) {
        console.warn("CORS/Fetch Blocked for remote PDF, activating simulator creative engine fallback:", corsErr);
        if (active) {
          setIsCorsTriggered(true);
          setLoadingPdf(false);
        }
      }
    }

    async function renderAllPages(pdfDoc: any) {
      const container = document.getElementById("pdf_renderer_stack");
      if (!container) return;

      const numPages = pdfDoc.numPages;
      for (let pageNum = 1; pageNum <= numPages; pageNum++) {
        const page = await pdfDoc.getPage(pageNum);
        const viewport = page.getViewport({ scale: 1.5 }); // High-def default scale
        
        const canvas = document.createElement("canvas");
        canvas.className = "w-full shadow-2xl mb-5 rounded-lg border border-white/5 bg-[#0f111a] transition-transform duration-300";
        canvas.id = `pdf-canvas-page-${pageNum}`;
        const context = canvas.getContext("2d");

        canvas.height = viewport.height;
        canvas.width = viewport.width;

        if (context) {
          const renderContext = {
            canvasContext: context,
            viewport: viewport
          };
          await page.render(renderContext).promise;
          container.appendChild(canvas);
        }
      }
    }

    renderPdfDocument();

    return () => {
      active = false;
    };
  }, [episode.id, pdfJsLoaded]);

  // Adjust canvas size scaling for zoom dynamically
  useEffect(() => {
    const pages = document.getElementById("pdf_renderer_stack");
    if (pages) {
      pages.style.transform = `scale(${zoom / 100})`;
      pages.style.transformOrigin = "top center";
    }
  }, [zoom]);

  return (
    <div className="flex flex-col h-full bg-[#040508] relative" id="nexonshelf_reader_viewport">
      
      {/* Reader Floating Header Panel */}
      <div className="h-14 bg-slate-950/90 border-b border-blue-500/10 px-4 flex items-center justify-between shrink-0 sticky top-0 z-20 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1 hover:bg-white/5 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
            title="Keluar Pembaca"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div>
            <h4 className="text-[10px] uppercase font-bold tracking-widest text-[#5569ff] font-mono leading-none">
              {work.title}
            </h4>
            <span className="text-xs text-white font-extrabold line-clamp-1 mt-1">{episode.title}</span>
          </div>
        </div>

        {/* Previous / Next buttons */}
        <div className="flex items-center gap-2">
          {prevEpisode ? (
            <button
              onClick={() => onSwitchEpisode(prevEpisode)}
              className="py-1 px-2 bg-blue-900/20 hover:bg-blue-500/20 text-blue-400 hover:text-white text-[10px] font-bold font-mono rounded-lg transition-colors border border-blue-900/30 flex items-center gap-1 cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>SEBELUM</span>
            </button>
          ) : (
            <span className="text-[10px] text-white/10 font-mono italic px-2 py-1">BAB PERDANA</span>
          )}

          {nextEpisode ? (
            <button
              onClick={() => onSwitchEpisode(nextEpisode)}
              className="py-1 px-2 bg-blue-600 hover:bg-blue-550 active:scale-95 text-white text-[10px] font-bold font-mono rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
            >
              <span>BERIKUT</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <span className="text-[10px] text-emerald-400 font-mono font-bold bg-emerald-500/10 px-2 py-1 rounded-md border border-emerald-500/20 uppercase tracking-widest animate-pulse">TAMAT</span>
          )}
        </div>
      </div>

      {/* Reader continuous scroll wrapper */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto px-2 sm:px-6 py-6 scrollbar-thin scrollbar-thumb-blue-600 flex flex-col items-center"
      >
        <div className="max-w-2xl w-full select-none text-center">
          
          {loadingPdf && (
            <div className="py-32 flex flex-col items-center justify-center gap-3">
              <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
              <p className="text-xs font-mono tracking-wider text-blue-300">Menyusun halaman buku...</p>
            </div>
          )}

          {/* Secure Fallback Simulator if CORS triggered or PDF is missing */}
          {isCorsTriggered && (
            <ComicFallbackPanel 
              episode={episode} 
              onNextEp={nextEpisode ? () => onSwitchEpisode(nextEpisode) : null}
            />
          )}

          {/* Real Canvas Stack Container scaled by zoom */}
          <div className="relative w-full overflow-visible flex justify-center">
            <div 
              id="pdf_renderer_stack" 
              className="w-full origin-top transition-all"
            ></div>
          </div>

          {/* Reader Footer Page Navigation */}
          {!loadingPdf && !isCorsTriggered && (
            <div className="py-10 border-t border-white/5 mt-10 space-y-4">
              <p className="text-xs text-white/50 font-mono">--- Selesai Membaca episode ini ---</p>
              <div className="flex items-center justify-center gap-4">
                {prevEpisode && (
                  <button
                    onClick={() => {
                      onSwitchEpisode(prevEpisode);
                      scrollRef.current?.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                    className="py-2 px-4 bg-white/5 hover:bg-white/10 text-white text-xs font-bold font-mono rounded-xl border border-white/10 cursor-pointer"
                  >
                    EPISODE SEBELUMNYA
                  </button>
                )}
                {nextEpisode ? (
                  <button
                    onClick={() => {
                      onSwitchEpisode(nextEpisode);
                      scrollRef.current?.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                    className="py-2 px-5 bg-blue-600 hover:bg-blue-550 text-white text-xs font-bold font-mono rounded-xl hover:shadow-[0_0_15px_rgba(37,99,235,0.4)] cursor-pointer"
                  >
                    EPISODE BERIKUTNYA
                  </button>
                ) : (
                  <button
                    onClick={onBack}
                    className="py-2 px-5 bg-blue-900/20 hover:bg-blue-900/40 text-blue-400 text-xs font-bold font-mono rounded-xl border border-blue-500/20 cursor-pointer"
                  >
                    KEMBALI KE DETAIL UTAMA
                  </button>
                )}
              </div>
            </div>
          )}

        </div>
      </div>

      {/* Floating Bottom Zoom Control Panel */}
      {!loadingPdf && !isCorsTriggered && (
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 px-4 py-2 bg-[#090b14]/90 border border-blue-550/20 rounded-2xl flex items-center justify-between gap-4 backdrop-blur-md shadow-[0_10px_35px_rgba(0,0,0,0.8)] z-40">
          <button
            onClick={() => setZoom(prev => Math.max(70, prev - 15))}
            className="p-1.5 hover:bg-white/10 text-blue-400 hover:text-white rounded-lg cursor-pointer transition-colors"
            title="Perkecil (-)"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          
          <span className="text-[10px] font-mono font-bold tracking-wider text-white select-none w-12 text-center">
            {zoom}%
          </span>

          <button
            onClick={() => setZoom(prev => Math.min(180, prev + 15))}
            className="p-1.5 hover:bg-white/10 text-blue-400 hover:text-white rounded-lg cursor-pointer transition-colors"
            title="Perbesar (+)"
          >
            <ZoomIn className="w-4 h-4" />
          </button>

          <div className="w-px h-4 bg-white/10"></div>

          <button
            onClick={() => setZoom(100)}
            className="p-1 px-1.5 hover:bg-white/10 text-[9px] text-blue-350 cursor-pointer font-bold font-mono rounded text-center transition-colors border border-blue-500/20"
            title="Normal (100%)"
          >
            FIT
          </button>
        </div>
      )}

    </div>
  );
}

// ---------------------------------------------------------------------
// COMIC FALLBACK PANEL (GORGEOUS Cyberpunk Manga Frame with rich Canvas)
// ---------------------------------------------------------------------
interface ComicFallbackPanelProps {
  episode: NexonEpisode;
  onNextEp: (() => void) | null;
}

function ComicFallbackPanel({ episode, onNextEp }: ComicFallbackPanelProps) {
  return (
    <div className="w-full bg-[#0d101d] border border-blue-500/20 rounded-3xl p-6 sm:p-8 space-y-6 text-left shadow-2xl relative overflow-hidden animate-fadeIn my-4">
      {/* Ambient background accent */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none -z-10"></div>

      {/* Warning banner */}
      <div className="flex items-start gap-3 bg-amber-500/10 border border-amber-500/20 p-3.5 rounded-2xl">
        <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <h4 className="text-xs font-bold text-amber-300">Catatan Koneksi & CORS File</h4>
          <p className="text-[10px] text-[#cfd3ee]/80 leading-relaxed">
            Peramban Anda mendeteksi CORS-blocker saat mengunduh PDF instan dari {episode.pdfUrl.length > 50 ? `${episode.pdfUrl.substring(0, 50)}...` : episode.pdfUrl}. Tapi jangan khawatir, Nexon Engine mengaktifkan **Simulator Komik Digital** dengan visual menakjubkan di bawah!
          </p>
        </div>
      </div>

      {/* Cyberpunk Comic Frame Panel */}
      <div className="space-y-6">
        <div>
          <span className="text-[9px] bg-blue-500/15 text-blue-400 border border-blue-500/30 font-mono font-bold px-2.2 py-0.5 rounded-md uppercase tracking-widest">HALAMAN 1 • COMPILER SEMESTA</span>
          <h3 className="text-base font-black text-white mt-1 border-b border-white/5 pb-2">Nexon Chronicles: Rise of the Code Masters</h3>
        </div>

        {/* Panel Grid Layout mimicking real manga pages */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          
          {/* Comic Card 1 */}
          <div className="bg-gradient-to-tr from-[#121625] to-[#1a213a] rounded-2xl border border-blue-500/10 p-5 relative min-h-[190px] overflow-hidden flex flex-col justify-between shadow-lg">
            <div className="absolute -right-5 -bottom-5 w-24 h-24 bg-blue-500/10 rounded-full blur-xl pointer-events-none"></div>
            {/* Manga speech bubbles */}
            <div className="space-y-2">
              <div className="inline-block bg-white text-[#08090d] text-[10px] font-bold py-1 px-3.5 rounded-2xl rounded-tl-none font-sans shadow-md border border-white/40">
                &quot;Mons! Compiler Quantum mendeteksi letupan error di baris 42!&quot;
              </div>
            </div>
            
            {/* Visual simulation representation */}
            <div className="border border-cyan-500/20 rounded-xl bg-cyan-950/20 p-2.5 font-mono text-[9px] text-cyan-400 space-y-1 mt-4">
              <span className="text-cyan-503/40">// System Status terminal</span>
              <div>LET quantumLet = compilationEngine.vibrate();</div>
              <div className="text-[#ff5c5c] font-bold">ERROR: STACK_OVERFLOW_REALITY</div>
            </div>

            <span className="text-[8px] font-mono text-white/30 self-end mt-2 uppercase tracking-widest font-bold">Panel 01</span>
          </div>

          {/* Comic Card 2 */}
          <div className="bg-gradient-to-tr from-[#121625] to-[#1a213a] rounded-2xl border border-blue-500/10 p-5 relative min-h-[190px] overflow-hidden flex flex-col justify-between shadow-lg">
            <div className="absolute -left-5 -bottom-5 w-24 h-24 bg-purple-500/10 rounded-full blur-xl pointer-events-none"></div>
            {/* Speech bubble */}
            <div className="space-y-4">
              <div className="inline-block bg-indigo-500 text-white text-[10px] font-bold py-1 px-3.5 rounded-2xl rounded-tr-none font-sans shadow-md border border-indigo-400/40">
                &quot;Buka NexonShelf! Hanya admin yang bisa mengontrol override ini!&quot;
              </div>
              
              <div className="bg-white text-gray-950 text-[10px] font-bold py-1 px-3.5 rounded-2xl rounded-br-none font-sans shadow-md ml-auto max-w-[200px] text-right border border-white/30">
                &quot;Tenang, saya login menggunakan sandi admin dulu!&quot;
              </div>
            </div>

            <span className="text-[8px] font-mono text-white/30 self-end mt-2 uppercase tracking-widest font-bold">Panel 02</span>
          </div>

        </div>

        {/* Comic full spread card */}
        <div className="bg-gradient-to-br from-indigo-950/50 to-blue-950/30 border border-blue-500/20 rounded-2xl p-6 relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="absolute top-0 left-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl pointer-events-none"></div>
          <div className="space-y-2 max-w-lg">
            <span className="text-[9px] bg-indigo-500/15 text-indigo-400 font-mono font-bold px-2 py-0.5 rounded border border-indigo-500/30 uppercase tracking-widest">PANEL 03 • CLIMAX OVERLOAD</span>
            <p className="text-xs text-[#cfd3ee]/90 font-sans italic leading-relaxed">
              &quot;Dengan kekuatan dari Akademi Digital Nusantara, debugger NexonShelf mengaktifkan sinkronisasi quantum digital. Semua error disapu bersih secara bertahap!&quot;
            </p>
          </div>
          {onNextEp && (
            <button
              onClick={onNextEp}
              className="py-2 px-4 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white text-xs font-bold rounded-xl shadow-lg hover:shadow-blue-500/25 cursor-pointer shrink-0 transition-transform active:scale-95 text-center font-mono"
            >
              EPISODE BERIKUTNYA &rarr;
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
