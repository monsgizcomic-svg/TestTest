import React, { useState } from "react";
import { 
  auth, 
  db,
  handleFirestoreError,
  OperationType
} from "../lib/firebase";
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  updateProfile,
  GoogleAuthProvider,
  signInWithPopup
} from "firebase/auth";
import { 
  doc, 
  setDoc,
  getDoc
} from "firebase/firestore";
import { 
  Mail, 
  Lock, 
  User, 
  LogIn, 
  UserPlus, 
  AlertCircle, 
  BookOpen, 
  Building,
  GraduationCap
} from "lucide-react";

interface FirebaseAuthProps {
  onAddNotification: (title: string, msg: string) => void;
}

export default function FirebaseAuth({ onAddNotification }: FirebaseAuthProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [grade, setGrade] = useState("Member");
  const [school, setSchool] = useState("-");
  const [role, setRole] = useState("Member");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError("Silakan isi semua kolom input.");
      return;
    }
    if (password.length < 6) {
      setError("Kata sandi minimal berisi 6 karakter.");
      return;
    }

    setLoading(true);
    setError("");

    try {
      if (isLogin) {
        // Sign In
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        onAddNotification(
          "Masuk Berhasil! 🔑",
          `Selamat datang kembali, ${userCredential.user.displayName || userCredential.user.email}!`
        );
      } else {
        // Sign Up
        if (!name) {
          setError("Silakan isi nama lengkap Anda.");
          setLoading(false);
          return;
        }

        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;

        // Update auth profile display name
        await updateProfile(user, { displayName: name });

        // Save metadata to Firestore user record
        await setDoc(doc(db, "users", user.uid), {
          name: name,
          email: email,
          role: role,
          grade: grade,
          school: school,
          createdAt: new Date().toISOString()
        }).catch((error) => {
          handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
          throw error;
        });

        onAddNotification(
          "Registrasi Sukses! 🎉",
          "Akun Nexon Anda telah dibuat. Profil Anda disinkronkan secara pribadi."
        );
      }
    } catch (err: any) {
      console.error(err);
      let errorMsg = "Terjadi kesalahan sistem, silakan coba lagi.";
      if (err.code === "auth/user-not-found" || err.code === "auth/wrong-password") {
        errorMsg = "Email atau kata sandi Anda salah.";
      } else if (err.code === "auth/invalid-credential") {
        errorMsg = "Kredensial salah. Periksa kembali email dan password.";
      } else if (err.code === "auth/email-already-in-use") {
        errorMsg = "Email ini sudah terdaftar oleh pengguna lain.";
      } else if (err.code === "auth/invalid-email") {
        errorMsg = "Format penulisan email tidak valid.";
      } else if (err.code === "auth/weak-password") {
        errorMsg = "Kata sandi terlalu lemah. Gunakan minimal 6 karakter.";
      } else if (err.code === "auth/operation-not-allowed") {
        errorMsg = "Metode pendaftaran Email & Kata Sandi belum diaktifkan di Firebase Console Anda. Silakan hubungi admin.";
      }
      setError(errorMsg);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setLoading(true);
    setError("");
    try {
      const provider = new GoogleAuthProvider();
      const userCredential = await signInWithPopup(auth, provider);
      const user = userCredential.user;

      // Check if user record exists in Firestore
      const userDocRef = doc(db, "users", user.uid);
      const userDocSnap = await getDoc(userDocRef).catch((error) => {
        handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
        throw error;
      });

      if (!userDocSnap.exists()) {
        // If not, write initial metadata
        await setDoc(userDocRef, {
          name: user.displayName || user.email?.split("@")[0] || "User Nexon",
          email: user.email,
          role: "Member",
          grade: "Member",
          school: "-",
          createdAt: new Date().toISOString()
        }).catch((error) => {
          handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
          throw error;
        });
      }

      onAddNotification(
        "Masuk Berhasil! 🌐",
        `Selamat datang kembali, ${user.displayName || user.email}!`
      );
    } catch (err: any) {
      console.error(err);
      if (err.code === "auth/popup-blocked") {
        setError("Popup masuk diblokir oleh peramban. Silakan periksa pengaturan browser Anda.");
      } else if (err.code === "auth/operation-not-allowed") {
        setError("Metode pendaftaran Google belum diaktifkan di Firebase Console Anda. Silakan hubungi admin.");
      } else {
        setError(err.message || "Terjadi kesalahan saat masuk dengan Google.");
      }
    } finally {
      setLoading(false);
    }
  };




          


  return (
    <div className="w-full max-w-md mx-auto bg-[#0d0f17]/90 border border-white/10 rounded-2xl p-6 md:p-8 shadow-2xl relative overflow-hidden backdrop-blur-xl animate-fadeIn font-sans" id="nexon_firebase_auth_card">
      
      {/* Small floating accents */}
      <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none"></div>
      
      <div className="text-center space-y-2 mb-6">
        <h2 className="text-xl md:text-2xl font-black text-white tracking-tight leading-tight">
          {isLogin ? "Masuk ke NexonPortal" : "Buat Akun Baru Nexon"}
        </h2>
        <p className="text-xs text-white/50 leading-relaxed">
          {isLogin 
            ? "Gunakan akun personal Anda untuk mensinkronkan data asisten, chat AI, dan reminder alarm Anda." 
            : "Daftarkan akun personal Anda. Data Anda akan disimpan aman di Cloud Firestore secara terpisah dari user lain."
          }
        </p>
      </div>

      {error && (
        <div className="p-3 bg-red-500/10 border border-red-500/25 rounded-xl flex items-start gap-2 text-xs text-red-350 animate-shake mb-4" id="auth_error_container">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleAuth} className="space-y-4">
        
        {/* Sign Up extra fields */}
        {!isLogin && (
          <div className="space-y-1">
            <label className="block text-[11px] font-bold text-white/60 tracking-wider uppercase font-mono">Nama Lengkap</label>
            <div className="relative">
              <User className="absolute left-3 top-3.5 w-4 h-4 text-white/30" />
              <input
                type="text"
                placeholder="Contoh: Mons Giz"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-[#12141c] border border-white/5 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white/90 placeholder-white/20 focus:border-indigo-500/50 outline-none transition-all font-sans"
                required
              />
            </div>
          </div>
        )}

        {/* Email Address */}
        <div className="space-y-1">
          <label className="block text-[11px] font-bold text-white/60 tracking-wider uppercase font-mono">Alamat Email</label>
          <div className="relative">
            <Mail className="absolute left-3 top-3.5 w-4 h-4 text-white/30" />
            <input
              type="email"
              placeholder="nama@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-[#12141c] border border-white/5 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white/90 placeholder-white/20 focus:border-indigo-500/50 outline-none transition-all font-sans"
              required
            />
          </div>
        </div>

        {/* Password */}
        <div className="space-y-1">
          <label className="block text-[11px] font-bold text-white/60 tracking-wider uppercase font-mono">Kata Sandi</label>
          <div className="relative">
            <Lock className="absolute left-3 top-3.5 w-4 h-4 text-white/30" />
            <input
              type="password"
              placeholder="Minimal 6 karakter"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-[#12141c] border border-white/5 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white/90 placeholder-white/20 focus:border-indigo-500/50 outline-none transition-all font-sans"
              required
            />
          </div>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={loading}
          className="w-full mt-2 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-550 hover:to-purple-550 text-white rounded-xl text-xs font-bold font-mono tracking-wider transition-all shadow-xl flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed transform active:scale-98"
        >
          {loading ? (
            <span className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin"></span>
          ) : isLogin ? (
            <>
              <LogIn className="w-4 h-4" />
              <span>MASUK PORTAL</span>
            </>
          ) : (
            <>
              <UserPlus className="w-4 h-4" />
              <span>DAFTAR SEKARANG</span>
            </>
          )}
        </button>

        {/* Divider */}
        <div className="flex items-center my-4">
          <div className="flex-1 border-t border-white/5"></div>
          <span className="px-3 text-[10px] uppercase tracking-wider text-white/30 font-mono font-bold">atau</span>
          <div className="flex-1 border-t border-white/5"></div>
        </div>

        {/* Google Sign-In Button */}
        <button
          type="button"
          onClick={handleGoogleSignIn}
          disabled={loading}
          className="w-full py-2.5 bg-white text-gray-900 hover:bg-gray-100 rounded-xl text-xs font-bold font-sans transition-all flex items-center justify-center gap-2.5 shadow-md cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed transform active:scale-98"
        >
          <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
            />
          </svg>
          <span className="font-bold">MASUK DENGAN GOOGLE</span>
        </button>
      </form>


      {/* Switch between Sign In / Sign Up */}
      <div className="mt-6 text-center text-xs text-white/45">
        <span>{isLogin ? "Belum punya akun?" : "Sudah terdaftar?"}</span>{" "}
        <button
          type="button"
          onClick={() => {
            setIsLogin(!isLogin);
            setError("");
          }}
          className="text-indigo-400 hover:text-indigo-350 hover:underline font-bold transition-all cursor-pointer bg-transparent border-none p-0 outline-none"
        >
          {isLogin ? "Daftar Akun Baru" : "Masuk dengan Akun"}
        </button>
      </div>

    </div>
  );
}
