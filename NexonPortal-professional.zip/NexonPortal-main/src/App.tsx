/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { 
  Compass, 
  BookOpen, 
  Terminal, 
  Bell, 
  Bot, 
  Heart, 
  Sparkles, 
  Menu, 
  X, 
  HelpCircle, 
  Activity, 
  GraduationCap,
  LogOut
} from "lucide-react";

// Import modular panels
import DianaChat from "./components/DianaChat";
import LianaCounsel from "./components/LianaCounsel";
import NexonCodeStudio from "./components/NexonCodeStudio";
import NexonLabSandbox from "./components/NexonLabSandbox";
import SmartReminder from "./components/SmartReminder";
import TiltCard from "./components/TiltCard";

// Import Firebase
import { auth, db, handleFirestoreError, OperationType } from "./lib/firebase";
import { onAuthStateChanged, signOut, User as FirebaseUser } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import FirebaseAuth from "./components/FirebaseAuth";
import UserProfileEditor from "./components/UserProfileEditor";
import NexonShelf from "./components/NexonShelf";

interface ToastNotification {
  id: string;
  title: string;
  msg: string;
  timestamp: string;
}

export default function App() {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [isAuthChecking, setIsAuthChecking] = useState(true);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  const [currentView, setCurrentView] = useState<"portal" | "academic" | "nexonShelf">("portal");
  const [isEnteringApp, setIsEnteringApp] = useState(false);
  const [activeTab, setActiveTab] = useState<"home" | "diana" | "liana" | "code" | "lab" | "reminders">("home");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [userProfile, setUserProfile] = useState({
    name: "Mons Giz",
    role: "Siswa Siswi",
    grade: "Kelas XII MIPA - SMA",
    school: "Akademi Digital Nusantara"
  });

  // Tracks whether we should still show the "enable notifications" prompt.
  // Browsers require requestPermission() to be triggered by a direct user
  // gesture (a tap), so this can't be requested automatically on login —
  // we show a small dismissible prompt instead and only ask when tapped.
  const [notifPermission, setNotifPermission] = useState<NotificationPermission | "unsupported">(
    typeof window !== "undefined" && "Notification" in window ? Notification.permission : "unsupported"
  );

  // Floating notifications/alerts array
  const [toasts, setToasts] = useState<ToastNotification[]>([]);

  // Freeze all CSS animations while the tab is hidden/backgrounded.
  // Chrome on Android can corrupt compositor layers when several infinite
  // animations (pulse/spin/bounce) get suspended mid-cycle by the OS during
  // an app switch, producing visible ghosting/ "double text" artifacts when
  // the tab becomes visible again. Pausing them while hidden avoids that.
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        document.body.classList.add("app-bg-paused");
      } else {
        document.body.classList.remove("app-bg-paused");
      }
    };
    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => document.removeEventListener("visibilitychange", handleVisibilityChange);
  }, []);

  const handleAddToast = (title: string, msg: string) => {
    const freshToast: ToastNotification = {
      id: "toast-" + Date.now(),
      title,
      msg,
      timestamp: new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })
    };
    
    setToasts(prev => [freshToast, ...prev].slice(0, 5)); // Keep last 5 popups

    // Auto-remove toast after 6 seconds
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== freshToast.id));
    }, 6000);

    // Mirror the in-app toast as a real OS-level notification when the tab
    // isn't focused (switched app, locked screen, other tab) so important
    // alerts aren't missed just because Chrome isn't on screen. Silently
    // does nothing if the browser/user hasn't granted permission.
    if (typeof window !== "undefined" && "Notification" in window && document.hidden) {
      if (Notification.permission === "granted") {
        try {
          new Notification(title, { body: msg, icon: "/icon.png", tag: freshToast.id });
        } catch (e) {
          console.warn("Gagal menampilkan notifikasi OS:", e);
        }
      }
    }
  };

  const handleRequestNotifPermission = async () => {
    if (typeof window === "undefined" || !("Notification" in window)) return;
    try {
      const result = await Notification.requestPermission();
      setNotifPermission(result);
      if (result === "granted") {
        handleAddToast("Notifikasi Diaktifkan", "Kamu akan tetap menerima notifikasi penting walau berpindah aplikasi.");
      }
    } catch (e) {
      console.warn("Gagal meminta izin notifikasi:", e);
    }
  };

  // Welcome user with toast and set up authentication state listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        // Fetch custom user profile details from Firestore asynchronously in the background
        const fetchProfile = async () => {
          try {
            const docRef = doc(db, "users", user.uid);
            const docSnap = await getDoc(docRef);
            if (docSnap && docSnap.exists()) {
              const data = docSnap.data();
              setUserProfile({
                name: data.name || user.displayName || user.email?.split("@")[0] || "User Nexon",
                role: data.role || "Member",
                grade: data.grade || "Member",
                school: data.school || "-"
              });
            } else {
              // Setup default profile from email/displayName
              const defaultName = user.displayName || user.email?.split("@")[0] || "User Nexon";
              setUserProfile({
                name: defaultName,
                role: "Member",
                grade: "Member",
                school: "-"
              });
            }
          } catch (err) {
            console.warn("User profile Firestore access restricted or database not created yet:", err);
            const defaultName = user.displayName || user.email?.split("@")[0] || "User Nexon";
            setUserProfile({
              name: defaultName,
              role: "Member",
              grade: "Member",
              school: "-"
            });
          }
        };
        fetchProfile();

        handleAddToast(
          "Autentikasi Aman! 🔓",
          `Selamat datang di sistem portal pribadi Anda, ${user.email}!`
        );
      } else {
        setUserProfile({
          name: "Guest Node",
          role: "Member",
          grade: "Member",
          school: "-"
        });
      }
      setIsAuthChecking(false);
    });

    return () => unsubscribe();
  }, []);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setCurrentView("portal");
      handleAddToast("Log Out Berhasil! 🔒", "Sesi Anda telah dihentikan dengan aman.");
    } catch (err) {
      console.error(err);
    }
  };

  const handleProfileSaveSuccess = (updated: { name: string; role: string; grade: string; school: string }) => {
    setUserProfile(updated);
  };

  if (isAuthChecking) {
    return (
      <div className="min-h-screen bg-[#0a0a0c] text-white/90 flex flex-col items-center justify-center font-sans">
        <div className="w-10 h-10 border-4 border-indigo-500/10 border-t-indigo-500 rounded-full animate-spin mb-4"></div>
        <p className="text-xs text-white/40 tracking-wider font-mono uppercase animate-pulse">[ Memverifikasi Integritas Authentikasi... ]</p>
      </div>
    );
  }

  // If user is not authenticated, lock portal under FirebaseAuth view
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-[#0a0a0c] text-white/90 flex flex-col font-sans relative overflow-hidden" id="nexon_portal_hub">
        
        {/* Subtle background accent — one quiet glow instead of competing colors */}
        <div className="absolute top-0 left-1/3 w-96 h-96 bg-indigo-600/[0.06] rounded-full blur-3xl pointer-events-none -z-10"></div>

        {/* Global Header */}
        <header className="bg-[#131316] border-b border-white/5 h-16 pt-safe flex items-center justify-between px-4 sm:px-6 sticky top-0 z-40">
          <div className="flex items-center gap-2.5">
            <div>
              <span className="font-extrabold tracking-tight text-white/95 text-lg block font-display">
                NexonPortal
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 inline-block pointer-events-none animate-pulse"></span>
            <span className="text-xs text-white/60 font-mono">Sistem Terkunci</span>
          </div>
        </header>

        {/* Auth Body Area */}
        <main className="flex-1 max-w-5xl w-full mx-auto px-4 py-8 md:py-12 flex flex-col justify-center items-center">
          
          {/* Welcome Title Banner */}
          <div className="text-center space-y-3 mb-8 max-w-2xl mx-auto">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-medium bg-white/[0.05] text-white/50 border border-white/[0.08]">
              Portal Ekosistem Nexon
            </span>
            <h1 className="text-3xl md:text-4xl font-bold text-white tracking-tight leading-tight font-display">
              Selamat Datang di <span className="text-indigo-400">NexonPortal</span>
            </h1>
            <p className="text-white/50 text-xs md:text-sm leading-relaxed max-w-sm mx-auto">
              Silakan mendaftar atau masuk menggunakan akun personal Anda untuk menikmati fitur asisten kurikulum akademik interaktif.
            </p>
          </div>

          {/* Render Authenticator */}
          <FirebaseAuth onAddNotification={handleAddToast} />

        </main>

        <footer className="h-14 border-t border-white/5 flex items-center justify-center px-4 bg-[#131316] text-[10px] text-white/30 font-mono tracking-wider">
          PORTAL EKOSISTEM NEXON &copy; 2026 &bull; AMAN DAN TERKODE DI CLOUD
        </footer>

        {/* Global Toasts rendering.
            On mobile this sits top-center, below the safe-area inset, so it
            never covers the chat input or bottom action buttons. On desktop
            it moves to the familiar bottom-right corner. */}
        <div
          className="fixed top-3 left-3 right-3 sm:top-auto sm:left-auto sm:bottom-4 sm:right-4 pt-safe z-50 space-y-2.5 sm:max-w-sm sm:w-full font-sans pointer-events-none"
          id="nexon_toast_portal"
        >
          {toasts.map((toast) => (
            <div
              key={toast.id}
              className="p-3.5 bg-slate-905 border border-slate-100/10 text-white rounded-2xl shadow-xl flex items-start gap-3 bg-[#131316] animate-slideIn border-l-4 border-l-indigo-500 pointer-events-auto"
            >
              <div className="p-1.5 bg-indigo-500/15 rounded-lg text-indigo-300 shrink-0 mt-0.5 animate-pulse">
                <Bell className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1">
                  <span className="font-bold text-xs text-white truncate">{toast.title}</span>
                  <span className="text-[9px] text-slate-450 font-mono shrink-0">{toast.timestamp}</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed mt-1 whitespace-pre-line">{toast.msg}</p>
              </div>
              <button
                onClick={() => setToasts(prev => prev.filter(t => t.id !== toast.id))}
                className="p-1 text-slate-500 hover:text-white rounded-full cursor-pointer transition-colors shrink-0"
                title="Tutup Notifikasi"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>

      </div>
    );
  }


  if (currentView === "portal") {
    return (
      <div className="min-h-screen bg-[#0a0a0c] text-white/90 flex flex-col font-sans relative overflow-hidden" id="nexon_portal_hub">
        
        {/* Subtle background accent — one quiet glow instead of competing colors */}
        <div className="absolute top-0 left-1/3 w-96 h-96 bg-indigo-600/[0.06] rounded-full blur-3xl pointer-events-none -z-10"></div>

        {/* Global Header */}
        <header className="bg-[#131316] border-b border-white/5 h-16 pt-safe flex items-center justify-between px-4 sm:px-6 sticky top-0 z-40">
          <div className="flex items-center gap-2.5">
            <div>
              <span className="font-extrabold tracking-tight text-white/95 text-lg block font-display">
                NexonPortal
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Clickable Profile Card */}
            <div 
              onClick={() => setIsProfileModalOpen(true)}
              className="flex items-center gap-2.5 bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-xl border border-white/5 hover:border-indigo-500/30 cursor-pointer transition-all shrink-0"
              title="Edit Profil"
            >
              <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-purple-500 to-pink-500 text-white flex items-center justify-center font-bold text-[10px] border border-white/10 shrink-0">
                {userProfile.name ? userProfile.name.substring(0, 2).toUpperCase() : "NX"}
              </div>
              <span className="text-xs text-white/80 font-medium hidden sm:inline">{userProfile.name}</span>
            </div>

            {/* Logout Button */}
            <button 
              onClick={handleLogout}
              className="py-1.5 px-3 bg-red-500/10 hover:bg-red-500/20 text-red-400 hover:text-red-350 border border-red-500/20 text-xs font-bold font-mono rounded-xl cursor-pointer transition-colors flex items-center gap-1.5 shrink-0"
              title="Keluar"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        </header>

        {/* Start-up Loader Sequence */}
        {isEnteringApp && (
          <div className="fixed inset-0 bg-[#0a0a0c]/95 backdrop-blur-md z-50 flex flex-col items-center justify-center font-sans animate-fadeIn">
            <div className="w-16 h-16 border-4 border-indigo-550/10 border-t-indigo-500 rounded-full animate-spin mb-6"></div>
            <div className="space-y-1.5 text-center">
              <h3 className="text-sm font-semibold text-white tracking-widest uppercase font-display">Mempersiapkan Lingkungan</h3>
              <p className="text-[10px] text-indigo-400 font-mono tracking-widest animate-pulse">[ Memulai Instansi NexonAkademik...]</p>
            </div>
          </div>
        )}

        {/* Main Hub Body Area */}
        <main className="flex-1 max-w-5xl w-full mx-auto px-4 py-8 md:py-12 flex flex-col justify-center">
          
          {/* Welcome Title Banner */}
          <div className="text-center space-y-3 mb-10 max-w-2xl mx-auto">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-medium bg-white/[0.05] text-white/50 border border-white/[0.08]">
              Portal Ekosistem Nexon
            </span>
            <h1 className="text-3xl md:text-4xl font-bold text-white tracking-tight leading-tight">
              Gerbang Utama Aplikasi <span className="text-indigo-400 font-display">Nexon</span>
            </h1>
            <p className="text-white/50 text-xs md:text-sm leading-relaxed">
              Halo <strong className="text-white/80 font-semibold">{userProfile.name}</strong>, selamat datang di kontrol panel sistem Nexon. Di bawah ini adalah portofolio aplikasi Anda yang dapat diakses langsung.
            </p>
          </div>

          {/* Notification permission prompt — only shown when not yet decided */}
          {notifPermission === "default" && (
            <div className="mb-8 max-w-2xl mx-auto p-3.5 bg-white/[0.04] border border-white/[0.08] rounded-2xl flex items-center gap-3 text-left animate-fadeIn">
              <div className="w-8 h-8 rounded-full bg-indigo-500/15 text-indigo-400 flex items-center justify-center shrink-0">
                <Bell className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-white/80">Aktifkan notifikasi?</p>
                <p className="text-[11px] text-white/40">Tetap dapat pemberitahuan walau berpindah aplikasi atau tab.</p>
              </div>
              <button
                onClick={handleRequestNotifPermission}
                className="px-3 py-1.5 bg-white/90 hover:bg-white text-black text-xs font-medium rounded-lg cursor-pointer transition-colors shrink-0"
              >
                Aktifkan
              </button>
              <button
                onClick={() => setNotifPermission("denied")}
                className="p-1.5 text-white/30 hover:text-white/60 cursor-pointer shrink-0"
                title="Tutup"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
          {/* Touch-Friendly Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6" id="nexon_ecosystem_portal_grid">
            
            {/* 1. NexonAcademic (FULLY ACTIVE) */}
            <div 
              onClick={() => {
                setIsEnteringApp(true);
                setTimeout(() => {
                  setCurrentView("academic");
                  setIsEnteringApp(false);
                  handleAddToast(
                    "Memasuki NexonAcademic", 
                    "Gunakan Sidebar Navigasi Samping untuk berpindah instrumen kelas, simulasi lab, dan chatbot asisten."
                  );
                }, 1000);
              }}
              className="group bg-white/[0.03] hover:bg-white/[0.05] border border-white/[0.08] hover:border-indigo-500/40 rounded-3xl p-6 shadow-lg relative transition-all duration-200 cursor-pointer"
            >
              <div className="flex items-start justify-between">
                <div className="w-12 h-12 bg-indigo-500/10 rounded-2xl border border-indigo-500/15 flex items-center justify-center text-indigo-400">
                  <GraduationCap className="w-6 h-6" />
                </div>
                <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-medium bg-white/[0.04] text-white/40 border border-white/[0.06]">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-400"></span> Aktif
                </span>
              </div>

              <div className="mt-7 space-y-2">
                <h2 className="text-lg font-semibold text-white tracking-tight">
                  NexonAcademic
                </h2>
                <p className="text-white/50 text-xs leading-relaxed font-sans">
                  Asisten digital lengkap pendukung kurikulum MIPA. Mengintegrasikan Guru AI Diana, Guru BK Liana, NexonCode Studio, dan Laboratorium Kimia Interaktif NexonLab.
                </p>
              </div>

              <div className="pt-5 border-t border-white/[0.06] mt-5 flex items-center justify-between text-xs font-medium text-white/40 group-hover:text-indigo-300 transition-colors">
                <span>Ketuk untuk masuk</span>
                <span className="group-hover:translate-x-1 transition-transform">&rarr;</span>
              </div>
            </div>

            {/* 2. NexonShelf Aktif Comic Reader */}
            <div 
              onClick={() => {
                setIsEnteringApp(true);
                setTimeout(() => {
                  setCurrentView("nexonShelf");
                  setIsEnteringApp(false);
                  handleAddToast(
                    "Membuka NexonShelf", 
                    "Selamat datang di portal aktif komik digital dan literasi sains Akademi Siswa."
                  );
                }, 1000);
              }}
              className="group bg-white/[0.03] hover:bg-white/[0.05] border border-white/[0.08] hover:border-blue-500/40 rounded-3xl p-6 shadow-lg relative transition-all duration-200 cursor-pointer"
            >
              <div className="flex items-start justify-between">
                <div className="w-12 h-12 bg-blue-500/10 rounded-2xl border border-blue-500/15 flex items-center justify-center text-blue-400">
                  <BookOpen className="w-6 h-6" />
                </div>
                <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-medium bg-white/[0.04] text-white/40 border border-white/[0.06]">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span> Aktif
                </span>
              </div>

              <div className="mt-7 space-y-2">
                <h2 className="text-lg font-semibold text-white tracking-tight">
                  NexonShelf
                </h2>
                <p className="text-white/50 text-xs leading-relaxed font-sans">
                  Sub-directory portal penyimpanan literasi digital MIPA & kreasi fiksi sains. Dilengkapi layout baca vertikal scroll berteknologi PDF.js, galeri ilustrasi, dan panel kontribusi mandiri.
                </p>
              </div>

              <div className="pt-5 border-t border-white/[0.06] mt-5 flex items-center justify-between text-xs font-medium text-white/40 group-hover:text-blue-300 transition-colors">
                <span>Buka direktori literasi</span>
                <span className="group-hover:translate-x-1 transition-transform">&rarr;</span>
              </div>
            </div>

          </div>

          {/* Interactive touch hint */}
          <div className="mt-10 p-4 bg-white/[0.03] border border-white/[0.06] rounded-2xl text-center text-xs text-white/40 leading-relaxed font-sans max-w-lg mx-auto">
            <strong className="text-white/60 font-medium">Saran Tampilan HP:</strong> Ketukan kartu di atas sangat responsif. Anda dapat langsung meluncurkan atau meminta modul lain berjalan di ekosistem Nexon ini!
          </div>

        </main>

        <footer className="h-14 border-t border-white/5 flex items-center justify-center px-4 bg-[#131316] text-[10px] text-white/30 font-mono tracking-wider">
          PORTAL EKOSISTEM NEXON &copy; 2026 &bull; DIDESAIN UNTUK HP DAN LAPTOP
        </footer>

        {/* Global Toasts rendering.
            On mobile this sits top-center, below the safe-area inset, so it
            never covers the chat input or bottom action buttons. On desktop
            it moves to the familiar bottom-right corner. */}
        <div
          className="fixed top-3 left-3 right-3 sm:top-auto sm:left-auto sm:bottom-4 sm:right-4 pt-safe z-50 space-y-2.5 sm:max-w-sm sm:w-full font-sans pointer-events-none"
          id="nexon_toast_portal"
        >
          {toasts.map((toast) => (
            <div
              key={toast.id}
              className="p-3.5 bg-slate-905 border border-slate-100/10 text-white rounded-2xl shadow-xl flex items-start gap-3 bg-[#131316] animate-slideIn border-l-4 border-l-indigo-500 pointer-events-auto"
            >
              <div className="p-1.5 bg-indigo-500/15 rounded-lg text-indigo-300 shrink-0 mt-0.5 animate-pulse">
                <Bell className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1">
                  <span className="font-bold text-xs text-white truncate">{toast.title}</span>
                  <span className="text-[9px] text-slate-450 font-mono shrink-0">{toast.timestamp}</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed mt-1 whitespace-pre-line">{toast.msg}</p>
              </div>
              <button
                onClick={() => setToasts(prev => prev.filter(t => t.id !== toast.id))}
                className="p-1 text-slate-500 hover:text-white rounded-full cursor-pointer transition-colors shrink-0"
                title="Tutup Notifikasi"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>

        {/* Profile Modal */}
        {isProfileModalOpen && currentUser && (
          <UserProfileEditor
            user={currentUser}
            onClose={() => setIsProfileModalOpen(false)}
            onSaveSuccess={handleProfileSaveSuccess}
            onAddNotification={handleAddToast}
          />
        )}

      </div>
    );
  }

  if (currentView === "nexonShelf") {
    return (
      <NexonShelf
        userProfile={userProfile}
        onBackToPortal={() => setCurrentView("portal")}
        onAddNotification={handleAddToast}
        currentUserId={currentUser?.uid}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white/90 flex flex-col font-sans" id="nexon_academic_app">
      
      {/* 1. Header Bar */}
      <header className="bg-[#131316] border-b border-white/5 h-16 pt-safe shrink-0 flex items-center justify-between px-3 sm:px-4 sticky top-0 z-40" id="nexon_main_header">
        <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
          {/* Mobile hamburger menu toggle */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 hover:bg-white/5 rounded-lg text-white/60 md:hidden cursor-pointer shrink-0"
            title="Menu Navigasi"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          {/* Logo Badge */}
          <div className="flex items-center gap-2 select-none min-w-0">
            <div className="w-9 h-9 sm:w-12 sm:h-12 bg-indigo-600 rounded-xl flex items-center justify-center font-bold text-xl shadow-[0_0_20px_rgba(79,70,229,0.4)] border border-white/10 shrink-0">
              <GraduationCap className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
            </div>
            <div className="min-w-0">
              <span className="font-bold tracking-tight text-white/95 text-sm sm:text-lg block font-display truncate">
                NexonAcademic
              </span>
            </div>
          </div>
        </div>

        {/* User profile capsule and quick notifications */}
        <div className="flex items-center gap-3">
          {/* Quick study state stats */}
          <div className="hidden sm:flex items-center gap-2 text-xs font-semibold bg-white/5 border border-white/10 py-1.5 px-3 rounded-full text-indigo-300 shadow-[0_0_10px_rgba(99,102,241,0.15)]" title="Informasi Siswa">
            <span className="w-2 h-2 rounded-full bg-indigo-400 inline-block pointer-events-none animate-ping"></span>
            <span>{userProfile.grade}</span>
          </div>

          <div 
            onClick={() => setIsProfileModalOpen(true)}
            className="flex items-center gap-2 hover:bg-white/5 p-1 px-2 rounded-xl border border-transparent hover:border-white/5 cursor-pointer transition-all shrink-0"
            title="Edit Profil"
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-500 to-pink-500 text-white flex items-center justify-center font-bold text-xs border border-white/10">
              {userProfile.name ? userProfile.name.substring(0, 2).toUpperCase() : "NX"}
            </div>
            <div className="hidden md:block text-left pr-1">
              <div className="text-xs font-bold text-white/90 leading-none">{userProfile.name}</div>
              <span className="text-[9.5px] text-indigo-400 font-bold tracking-tight uppercase">{userProfile.role}</span>
            </div>
          </div>

          <button 
            onClick={handleLogout}
            className="p-2 hover:bg-red-500/10 text-red-405 hover:text-white border border-transparent hover:border-red-500/20 rounded-xl cursor-pointer transition-colors shrink-0"
            title="Logout Akun"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* 2. Main content and navigation wrapper */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Desktop Sidebar */}
        <aside className="bg-[#131316] w-64 border-r border-white/5 shrink-0 hidden md:flex flex-col justify-between p-4" id="nexon_desktop_sidebar">
          <div className="space-y-6">
            
            {/* System Portal Exit */}
            <div>
              <span className="block text-[10px] text-indigo-400 font-medium uppercase tracking-wider pl-3 mb-2">
                Sistem Hub
              </span>
              <button
                type="button"
                onClick={() => {
                  setCurrentView("portal");
                  handleAddToast("Kembali ke Portal! 🪐", "Anda telah kembali ke gerbang utama aplikasi Nexon.");
                }}
                className="w-full text-left py-2.5 px-3 rounded-xl text-xs font-bold flex items-center gap-2.5 bg-indigo-500/15 text-indigo-400 hover:bg-indigo-500/25 border border-indigo-500/30 transition-all cursor-pointer shadow-lg active:scale-98"
              >
                <span>&larr; Portal Utama Nexon</span>
              </button>
            </div>

            {/* Nav Menu */}
            <div>
              <span className="block text-[10px] text-white/30 font-medium uppercase tracking-wider pl-3 mb-2">
                Akademik Workspace
              </span>
              <nav className="space-y-1">
                <button
                  type="button"
                  onClick={() => setActiveTab("home")}
                  className={`w-full text-left py-2 px-3 rounded-xl text-xs font-semibold flex items-center gap-3 transition-all cursor-pointer ${
                    activeTab === "home" 
                      ? "bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 shadow-[0_0_15px_rgba(99,102,241,0.25)] font-bold scale-102" 
                      : "text-white/40 hover:bg-white/5 hover:text-white/80"
                  }`}
                >
                  <BookOpen className="w-4.5 h-4.5" />
                  <span>Dashboard Sekolah</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab("diana")}
                  className={`w-full text-left py-2 px-3 rounded-xl text-xs font-semibold flex items-center gap-3 transition-all cursor-pointer ${
                    activeTab === "diana" 
                      ? "bg-teal-500/20 text-teal-300 border border-teal-500/35 shadow-[0_0_15px_rgba(20,184,166,0.25)] font-bold" 
                      : "text-white/40 hover:bg-white/5 hover:text-white/80"
                  }`}
                >
                  <Bot className="w-4.5 h-4.5" />
                  <span>Diana (Guru Akademis)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab("liana")}
                  className={`w-full text-left py-2 px-3 rounded-xl text-xs font-semibold flex items-center gap-3 transition-all cursor-pointer ${
                    activeTab === "liana" 
                      ? "bg-rose-500/20 text-rose-300 border border-rose-500/35 shadow-[0_0_15px_rgba(244,63,94,0.25)] font-bold" 
                      : "text-white/40 hover:bg-white/5 hover:text-white/80"
                  }`}
                >
                  <Heart className="w-4.5 h-4.5" />
                  <span>Liana (Guru BK)</span>
                </button>
              </nav>
            </div>

            {/* SubWebs Menu */}
            <div>
              <span className="block text-[10px] text-white/30 font-medium uppercase tracking-wider pl-3 mb-2">
                Nexon Sub-Web Sandbox
              </span>
              <nav className="space-y-1">
                <button
                  type="button"
                  onClick={() => setActiveTab("code")}
                  className={`w-full text-left py-2 px-3 rounded-xl text-xs font-semibold flex items-center gap-3 transition-all cursor-pointer ${
                    activeTab === "code" 
                      ? "bg-amber-500/20 text-amber-300 border border-amber-500/35 shadow-[0_0_15px_rgba(245,158,11,0.25)] font-bold" 
                      : "text-white/40 hover:bg-white/5 hover:text-white/80"
                  }`}
                >
                  <Terminal className="w-4.5 h-4.5" />
                  <span>NexonCode (Coding AI)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab("lab")}
                  className={`w-full text-left py-2 px-3 rounded-xl text-xs font-semibold flex items-center gap-3 transition-all cursor-pointer ${
                    activeTab === "lab" 
                      ? "bg-emerald-500/20 text-emerald-350 border border-emerald-500/35 shadow-[0_0_15px_rgba(16,185,129,0.25)] font-bold" 
                      : "text-white/40 hover:bg-white/5 hover:text-white/80"
                  }`}
                >
                  <Compass className="w-4.5 h-4.5" />
                  <span>NexonLab (Sains & Reaksi)</span>
                </button>
              </nav>
            </div>

            {/* Smart reminder Menu */}
            <div>
              <span className="block text-[10px] text-white/30 font-medium uppercase tracking-wider pl-3 mb-2">
                Agenda & Notifikasi
              </span>
              <nav className="space-y-1">
                <button
                  type="button"
                  onClick={() => setActiveTab("reminders")}
                  className={`w-full text-left py-2 px-3 rounded-xl text-xs font-semibold flex items-center gap-3 transition-all cursor-pointer ${
                    activeTab === "reminders" 
                      ? "bg-indigo-500/20 text-indigo-300 border border-indigo-500/35 shadow-[0_0_15px_rgba(99,102,241,0.25)] font-bold" 
                      : "text-white/40 hover:bg-white/5 hover:text-white/80"
                  }`}
                >
                  <Bell className="w-4.5 h-4.5" />
                  <span>Pengingat & Alarm</span>
                </button>
              </nav>
            </div>

          </div>

          {/* School footer status */}
          <div className="bg-[#12141c] border border-white/5 rounded-xl p-3 text-[11px] space-y-1.5 font-mono text-white/40">
            <div className="text-white/60 font-bold flex items-center gap-1.5 leading-none">
              <span className="w-1.5 h-1.5 bg-green-500 rounded-full inline-block pointer-events-none animate-pulse"></span>
              <span>Sistem NexonAktif</span>
            </div>
            <p className="leading-tight text-[10px]">Tujuan Pendidikan: Membantu siswa belajar mandiri anti-stres.</p>
          </div>
        </aside>

        {/* Mobile Slideout Sidebar overlay/drawer */}
        {isMobileMenuOpen && (
          <div className="fixed inset-0 top-16 bg-black/70 z-30 md:hidden animate-fadeIn" onClick={() => setIsMobileMenuOpen(false)}>
            <div className="bg-[#131316] w-64 h-full p-4 space-y-6 flex flex-col justify-between border-r border-white/5" onClick={(e) => e.stopPropagation()}>
              <div className="space-y-6">
                
                {/* Back to Portal on Mobile */}
                <div>
                  <span className="block text-[10px] text-indigo-400 font-medium uppercase tracking-wider pl-3 mb-2">
                    Sistem Hub
                  </span>
                  <button
                    onClick={() => {
                      setCurrentView("portal");
                      setIsMobileMenuOpen(false);
                      handleAddToast("Kembali ke Portal! 🪐", "Anda telah kembali ke gerbang utama aplikasi Nexon.");
                    }}
                    className="w-full text-left py-3 px-3 rounded-xl text-xs font-bold flex items-center gap-2.5 bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 shadow-md active:bg-indigo-500/20"
                  >
                    <span>&larr; Portal Utama Nexon</span>
                  </button>
                </div>

                <div>
                  <span className="block text-[10px] text-white/30 font-medium uppercase tracking-wider pl-3 mb-2">
                    Workspace Akademik
                  </span>
                  <nav className="space-y-1">
                    <button
                      onClick={() => { setActiveTab("home"); setIsMobileMenuOpen(false); }}
                      className={`w-full text-left py-2.5 px-3 rounded-lg text-xs font-semibold flex items-center gap-3 ${
                        activeTab === "home" 
                          ? "bg-indigo-500/20 text-indigo-300 border border-indigo-500/20" 
                          : "text-white/40 hover:bg-white/5"
                      }`}
                    >
                      <BookOpen className="w-4.5 h-4.5" />
                      <span>Dashboard Utama</span>
                    </button>
                    <button
                      onClick={() => { setActiveTab("diana"); setIsMobileMenuOpen(false); }}
                      className={`w-full text-left py-2.5 px-3 rounded-lg text-xs font-semibold flex items-center gap-3 ${
                        activeTab === "diana" 
                          ? "bg-teal-500/20 text-teal-300 border border-teal-500/20" 
                          : "text-white/40 hover:bg-white/5"
                      }`}
                    >
                      <Bot className="w-4.5 h-4.5" />
                      <span>Diana (AI Akademis)</span>
                    </button>
                    <button
                      onClick={() => { setActiveTab("liana"); setIsMobileMenuOpen(false); }}
                      className={`w-full text-left py-2.5 px-3 rounded-lg text-xs font-semibold flex items-center gap-3 ${
                        activeTab === "liana" 
                          ? "bg-rose-500/20 text-rose-300 border border-rose-500/20" 
                          : "text-white/40 hover:bg-white/5"
                      }`}
                    >
                      <Heart className="w-4.5 h-4.5" />
                      <span>Liana (Guru BK)</span>
                    </button>
                  </nav>
                </div>

                <div>
                  <span className="block text-[10px] text-white/30 font-medium uppercase tracking-wider pl-3 mb-2">
                    Sandbox Platform
                  </span>
                  <nav className="space-y-1">
                    <button
                      onClick={() => { setActiveTab("code"); setIsMobileMenuOpen(false); }}
                      className={`w-full text-left py-2.5 px-3 rounded-lg text-xs font-semibold flex items-center gap-3 ${
                        activeTab === "code" 
                          ? "bg-amber-500/20 text-amber-300 border border-amber-500/20" 
                          : "text-white/40 hover:bg-white/5"
                      }`}
                    >
                      <Terminal className="w-4.5 h-4.5" />
                      <span>NexonCode (Coding AI)</span>
                    </button>
                    <button
                      onClick={() => { setActiveTab("lab"); setIsMobileMenuOpen(false); }}
                      className={`w-full text-left py-2.5 px-3 rounded-lg text-xs font-semibold flex items-center gap-3 ${
                        activeTab === "lab" 
                          ? "bg-emerald-500/20 text-emerald-305 border border-emerald-500/20" 
                          : "text-white/40 hover:bg-white/5"
                      }`}
                    >
                      <Compass className="w-4.5 h-4.5" />
                      <span>NexonLab (Tabel & Reaksi)</span>
                    </button>
                    <button
                      onClick={() => { setActiveTab("reminders"); setIsMobileMenuOpen(false); }}
                      className={`w-full text-left py-2.5 px-3 rounded-lg text-xs font-semibold flex items-center gap-3 ${
                        activeTab === "reminders" 
                          ? "bg-indigo-500/20 text-indigo-300 border border-indigo-500/20" 
                          : "text-white/40 hover:bg-white/5"
                      }`}
                    >
                      <Bell className="w-4.5 h-4.5" />
                      <span>Pengingat & Alarm</span>
                    </button>
                  </nav>
                </div>
              </div>

              <div className="bg-[#12141c] border border-white/5 p-3 rounded-lg text-[10px] font-mono text-white/30">
                Pendidikan Interaktif & Transparan
              </div>
            </div>
          </div>
        )}

        {/* 3. Central Working Page Canvas */}
        <main className="flex-1 p-4 md:p-6 overflow-y-auto" id="nexon_central_render_stage">
          
          {activeTab === "home" && (
            <div className="space-y-6 max-w-5xl mx-auto" id="nexon_home_tab_wrapper">
              
              {/* Beautiful greeting welcome card */}
              <div className="bg-[#131316] border border-white/10 rounded-2xl p-6 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-5 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-44 h-44 bg-gradient-to-tr from-indigo-500/10 via-purple-500/5 to-pink-500/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>
                
                <div className="space-y-2">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-mono">
                    <Sparkles className="w-3.5 h-3.5 animate-bounce text-indigo-400" />
                    <span>Inovasi Pembelajaran Digital</span>
                  </span>
                  <h2 className="text-xl md:text-2xl font-black text-white/95 leading-tight animate-fadeIn">
                    Halo, {userProfile.name}! 👋 <br className="sm:hidden" />
                    <span className="font-extrabold text-white/60 font-sans text-base block mt-1 font-normal">Mari taklukkan tugas akademis Anda tanpa stres di NexonAcademic.</span>
                  </h2>
                  <p className="text-white/40 text-xs leading-relaxed max-w-xl">
                    Sekolah virtual pendukung belajar mandiri terbaik. Didesain menyerupai teknologi Pelajarin.ai, berkolaborasi dengan materi sains, asisten programing, dan bimbingan konseling BK.
                  </p>
                </div>

                <div className="p-4 bg-white/5 border border-white/10 rounded-xl shrink-0 text-left min-w-[200px] font-mono text-xs text-white/50 space-y-1 shadow-lg">
                  <div className="font-bold text-white/90 mb-1 flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-indigo-400" /> Profil Pengguna
                  </div>
                  <div>Status: <span className="text-emerald-400 font-semibold">● Belajar Aktif</span></div>
                  <div>Instansi: <span className="text-white/80 font-semibold">{userProfile.school}</span></div>
                  <div>Waktu Sesi: <span className="text-white/80 font-semibold">22 Juni 2026</span></div>
                </div>
              </div>

              {/* Dynamic app capability dashboard tiles with tactile 3D hover/tilt effects */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5" id="nexon_dashboard_bento_grid">
                
                {/* Diana Card Tile */}
                <TiltCard 
                  onClick={() => setActiveTab("diana")}
                  className="bg-[#131316] border border-teal-500/20 hover:border-teal-400 rounded-2xl p-5 shadow-2xl flex flex-col justify-between"
                  id="diana_tilt_card"
                >
                  <div className="space-y-2.5">
                    <div className="w-10 h-10 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center font-bold text-lg select-none">
                      👩‍🏫
                    </div>
                    <div>
                      <h4 className="font-bold text-white/95 text-sm">Diana (Guru Akademis MIPA)</h4>
                      <p className="text-xs text-white/60 mt-1">
                        Koreksi berkas latihan soal, bahas rumus kuadratik, fisika, atau tanya apa saja materi pelajaran sekolahmu.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); setActiveTab("diana"); }}
                    className="w-full mt-4 py-2 bg-teal-500/10 text-teal-300 hover:bg-teal-500/20 hover:text-white border border-teal-500/20 text-xs font-bold font-mono rounded-xl cursor-pointer text-center block transition-colors"
                  >
                    Masuk Ruang Diana &rarr;
                  </button>
                </TiltCard>

                {/* Liana Card Tile */}
                <TiltCard 
                  onClick={() => setActiveTab("liana")}
                  className="bg-[#131316] border border-rose-500/20 hover:border-rose-400 rounded-2xl p-5 shadow-2xl flex flex-col justify-between"
                  id="liana_tilt_card"
                >
                  <div className="space-y-2.5">
                    <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-400 flex items-center justify-center font-bold text-lg select-none">
                      🧘‍♀️
                    </div>
                    <div>
                      <h4 className="font-bold text-white/95 text-sm">Liana (Pendamping BK Siswa)</h4>
                      <p className="text-xs text-white/60 mt-1">
                        Sampaikan keluh kesah, curhat masalah cemas nilai, atau tumpahkan beban ujian. Dilengkapi asisten latihan pernapasan.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); setActiveTab("liana"); }}
                    className="w-full mt-4 py-2 bg-rose-500/10 text-rose-300 hover:bg-rose-500/20 hover:text-white border border-rose-500/20 text-xs font-bold font-mono rounded-xl cursor-pointer text-center block transition-colors"
                  >
                    Curhat Sehat Bersama Liana &rarr;
                  </button>
                </TiltCard>

                {/* NexonCode Card Tile */}
                <TiltCard 
                  onClick={() => setActiveTab("code")}
                  className="bg-[#131316] border border-amber-500/20 hover:border-amber-400 rounded-2xl p-5 shadow-2xl flex flex-col justify-between"
                  id="nexoncode_tilt_card"
                >
                  <div className="space-y-2.5">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center font-bold text-lg select-none">
                      💻
                    </div>
                    <div>
                      <h4 className="font-bold text-white/95 text-sm">NexonCode (AI Coding Studio)</h4>
                      <p className="text-xs text-white/60 mt-1">
                        Asisten tulis kode kilat. Men-generate baris kode bersih berbagai bahasa lengkap dengan penjelasan interaktif.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); setActiveTab("code"); }}
                    className="w-full mt-4 py-2 bg-amber-500/10 text-amber-350 hover:bg-amber-500/20 hover:text-white border border-amber-500/20 text-xs font-bold font-mono rounded-xl cursor-pointer text-center block transition-colors"
                  >
                    Nyalakan NexonCode IDE &rarr;
                  </button>
                </TiltCard>

                {/* NexonLab Card Tile */}
                <TiltCard 
                  onClick={() => setActiveTab("lab")}
                  className="bg-[#131316] border border-emerald-500/20 hover:border-emerald-400 rounded-2xl p-5 shadow-2xl flex flex-col justify-between"
                  id="nexonlab_tilt_card"
                >
                  <div className="space-y-2.5">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold text-lg select-none">
                      🧪
                    </div>
                    <div>
                      <h4 className="font-bold text-white/95 text-sm">NexonLab (Sains & Reaksi)</h4>
                      <p className="text-xs text-white/60 mt-1">
                        Jelajahi peta tabel unsur atom termodinamika secara mendalam, serta simulasikan uji reaksi kimia di tabung virtual.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); setActiveTab("lab"); }}
                    className="w-full mt-4 py-2 bg-emerald-500/10 text-emerald-350 hover:bg-emerald-500/20 hover:text-white border border-emerald-500/20 text-xs font-bold font-mono rounded-xl cursor-pointer text-center block transition-colors"
                  >
                    Masuk NexonLab Kimia &rarr;
                  </button>
                </TiltCard>

                {/* Smart reminders */}
                <TiltCard 
                  onClick={() => setActiveTab("reminders")}
                  className="bg-[#131316] border border-indigo-500/20 hover:border-indigo-400 rounded-2xl p-5 shadow-2xl flex flex-col justify-between"
                  id="reminders_tilt_card"
                >
                  <div className="space-y-2.5">
                    <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-450 flex items-center justify-center font-bold text-lg select-none">
                      ⏰
                    </div>
                    <div>
                      <h4 className="font-bold text-white/95 text-sm">Pengingat Jadwal Belajar</h4>
                      <p className="text-xs text-white/60 mt-1">
                        Atur alarm belajar Anda. Sistem akan memunculkan alarm, getaran, serta membacakan teks peringatan lewat ucapan suara.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); setActiveTab("reminders"); }}
                    className="w-full mt-4 py-2 bg-indigo-505/10 text-indigo-300 hover:bg-indigo-500/20 hover:text-white border border-indigo-500/20 text-xs font-bold font-mono rounded-xl cursor-pointer text-center block transition-colors"
                  >
                    Atur Alarm Agenda &rarr;
                  </button>
                </TiltCard>

                {/* Helpful Instruction Info Card */}
                <TiltCard 
                  className="bg-[#12141c] border border-white/10 rounded-2xl p-5 text-white flex flex-col justify-between shadow-2xl cursor-default"
                  id="instruction_tilt_card"
                >
                  <div className="space-y-2">
                    <div className="text-xs font-bold text-pink-400 font-mono flex items-center gap-1.5 uppercase">
                      <HelpCircle className="w-4 h-4 shrink-0" /> Panduan Pembelajaran
                    </div>
                    <p className="text-[11px] text-white/70 leading-relaxed font-sans">
                      NexonAcademic mensimulasikan asisten digital Pelajarin.ai dengan mengutamakan keramaian MIPA dan kenyamanan stabilitas kesehatan emosional Anda. Atur audio agar notifikasi berbunyi lancar.
                    </p>
                  </div>
                </TiltCard>

              </div>
            </div>
          )}

          {activeTab === "diana" && (
            <div className="w-full max-w-7xl mx-auto px-1">
              <DianaChat onAddNotification={handleAddToast} />
            </div>
          )}

          {activeTab === "liana" && (
            <div className="w-full max-w-7xl mx-auto px-1">
              <LianaCounsel onAddNotification={handleAddToast} />
            </div>
          )}

          {activeTab === "code" && (
            <div className="max-w-6xl mx-auto">
              <NexonCodeStudio onAddNotification={handleAddToast} />
            </div>
          )}

          {activeTab === "lab" && (
            <div className="max-w-6xl mx-auto">
              <NexonLabSandbox onAddNotification={handleAddToast} />
            </div>
          )}

          {activeTab === "reminders" && (
            <div className="max-w-6xl mx-auto">
              <SmartReminder onAddNotification={handleAddToast} />
            </div>
          )}

        </main>
      </div>

      {/* 4. Floating Toast alerts portal.
          Mobile: top-center, clear of the safe-area and the sidebar/chat
          input below. Desktop: classic bottom-right stack. */}
      <div
        className="fixed top-3 left-3 right-3 sm:top-auto sm:left-auto sm:bottom-4 sm:right-4 pt-safe z-50 space-y-2.5 sm:max-w-sm sm:w-full font-sans pointer-events-none"
        id="nexon_toast_portal"
      >
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className="p-3.5 bg-slate-905 border border-slate-100/10 text-white rounded-2xl shadow-xl flex items-start gap-3 bg-[#131316] animate-slideIn border-l-4 border-l-indigo-500 pointer-events-auto"
          >
            <div className="p-1.5 bg-indigo-500/15 rounded-lg text-indigo-300 shrink-0 mt-0.5 animate-pulse">
              <Bell className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1">
                <span className="font-bold text-xs text-white truncate">{toast.title}</span>
                <span className="text-[9px] text-slate-450 font-mono shrink-0">{toast.timestamp}</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed mt-1 whitespace-pre-line">{toast.msg}</p>
            </div>
            <button
              onClick={() => setToasts(prev => prev.filter(t => t.id !== toast.id))}
              className="p-1 text-slate-500 hover:text-white rounded-full cursor-pointer transition-colors shrink-0"
              title="Tutup Notifikasi"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>

      {/* Profile Modal */}
      {isProfileModalOpen && currentUser && (
        <UserProfileEditor
          user={currentUser}
          onClose={() => setIsProfileModalOpen(false)}
          onSaveSuccess={handleProfileSaveSuccess}
          onAddNotification={handleAddToast}
        />
      )}

    </div>
  );
}

