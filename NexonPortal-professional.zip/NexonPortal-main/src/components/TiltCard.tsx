import React, { useRef, useState, useEffect } from "react";
import { motion, useMotionValue, useTransform, useSpring } from "motion/react";

interface TiltCardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  id?: string;
}

export default function TiltCard({ children, className = "", onClick, id }: TiltCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);

  // Detect coarse-pointer (touch) devices once on mount. On these devices
  // mousemove never fires meaningfully, so the 3D tilt math below is dead
  // weight — we skip it entirely and fall back to a plain tap/active state.
  const [supportsHover, setSupportsHover] = useState(true);
  useEffect(() => {
    if (typeof window !== "undefined" && window.matchMedia) {
      setSupportsHover(window.matchMedia("(hover: hover) and (pointer: fine)").matches);
    }
  }, []);

  const x = useMotionValue(0);
  const y = useMotionValue(0);

  // Map normalized coordinates [-0.5, 0.5] to subtle rotate angles for premium 3D feeling
  const rotateX = useSpring(useTransform(y, [-0.5, 0.5], [8, -8]), { damping: 25, stiffness: 220 });
  const rotateY = useSpring(useTransform(x, [-0.5, 0.5], [-8, 8]), { damping: 25, stiffness: 220 });
  const scale = useSpring(1, { damping: 20, stiffness: 250 });
  const shadow = useSpring(0, { damping: 20, stiffness: 250 });

  const handleMouseMove = (event: React.MouseEvent<HTMLDivElement>) => {
    if (!supportsHover || !cardRef.current) return;
    
    const rect = cardRef.current.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    
    const mouseX = event.clientX - rect.left;
    const mouseY = event.clientY - rect.top;
    
    // Normalize coordinates to [-0.5, 0.5] range
    const relativeX = (mouseX / width) - 0.5;
    const relativeY = (mouseY / height) - 0.5;
    
    x.set(relativeX);
    y.set(relativeY);
    scale.set(1.025); // Subtle, elegant scale increase
    shadow.set(1);
  };
  
  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
    scale.set(1);
    shadow.set(0);
  };
  
  // Transform shadow scale into custom filter/shadow properties
  const boxShadow = useTransform(
    shadow,
    [0, 1],
    [
      "0 10px 30px -15px rgba(0,0,0,0.3)",
      "0 20px 40px -10px rgba(0,0,0,0.5)"
    ]
  );

  return (
    <motion.div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onClick={onClick}
      id={id}
      style={
        supportsHover
          ? {
              rotateX,
              rotateY,
              scale,
              boxShadow,
              transformStyle: "preserve-3d",
              perspective: 1000,
              cursor: onClick ? "pointer" : "default"
            }
          : {
              cursor: onClick ? "pointer" : "default"
            }
      }
      whileTap={!supportsHover && onClick ? { scale: 0.97 } : undefined}
      className={`transition-colors duration-200 ${supportsHover ? "" : "active:scale-[0.97]"} ${className}`}
    >
      {/* Internal shine/highlight accent following mouse movement */}
      <div 
        style={
          supportsHover
            ? { transform: "translateZ(30px)" }
            : undefined
        }
        className="w-full h-full flex flex-col justify-between"
      >
        {children}
      </div>
    </motion.div>
  );
}
