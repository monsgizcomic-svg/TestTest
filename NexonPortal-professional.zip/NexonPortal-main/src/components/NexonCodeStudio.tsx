import { useState, useRef, useEffect } from "react";
import { CodeMessage } from "../types";
import { renderFormattedText } from "./DianaChat";
import CodeBlock from "./CodeBlock";
import { 
  Send, 
  Copy, 
  Check, 
  Code2, 
  RefreshCw,
  Sparkles,
  Maximize2,
  Minimize2,
} from "lucide-react";

interface NexonCodeStudioProps {
  onAddNotification: (title: string, msg: string) => void;
}

const LANGUAGES = ["Python", "JavaScript", "TypeScript", "HTML/CSS", "C++", "Java", "SQL"];

const EXAMPLE_PROMPTS = [
  { label: "Fibonacci Recursion", q: "Buat algoritma deret Fibonacci secara rekursif lengkap dengan penjelasannya." },
  { label: "Validasi Form JS", q: "Bagaimana cara memvalidasi masukan alamat email dan kata sandi menggunakan regex di JavaScript?" },
  { label: "Koneksi Database", q: "Tulis kode koneksi database SQLite menggunakan Node.js dan cara query datanya." },
  { label: "Desain Flexbox CSS", q: "Buatkan contoh responsive card grid layout menggunakan HTML dasar dan CSS flexbox modern." }
];

const INITIAL_MESSAGE: CodeMessage = {
  id: "init-nexoncode",
  sender: "ai",
  text: "Halo! Saya **NexonCode**, asisten coding kamu di NexonAcademic.\n\nCeritakan apa yang ingin kamu bangun — fungsi, algoritma, potongan UI, query database, atau debugging. Saya akan ingat percakapan kita di sesi ini, jadi kamu bisa lanjut bertanya untuk merevisi kode sebelumnya tanpa mengulang dari awal.",
  timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
};

export default function NexonCodeStudio({ onAddNotification }: NexonCodeStudioProps) {
  // Persistent chat + code memory, same pattern as Diana's rooms — a page
  // refresh or revisit won't wipe out the student's coding session.
  const [messages, setMessages] = useState<CodeMessage[]>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("nexoncode_chat_history");
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) return parsed;
        } catch (e) {
          console.warn("Failed to parse NexonCode chat history");
        }
      }
    }
    return [INITIAL_MESSAGE];
  });

  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("nexoncode_chat_history", JSON.stringify(messages));
    }
  }, [messages]);

  const [inputText, setInputText] = useState("");
  const [selectedLang, setSelectedLang] = useState("Python");
  const [isLoading, setIsLoading] = useState(false);
  const [loadingLabel, setLoadingLabel] = useState("Menyusun kode...");
  const [isExpanded, setIsExpanded] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Progressively reassuring status text the longer a generation takes —
  // code generation can legitimately take several seconds, and a static
  // "loading" indicator with no change reads as frozen/broken past ~5s.
  useEffect(() => {
    if (!isLoading) {
      setLoadingLabel("Menyusun kode...");
      return;
    }
    const timers = [
      setTimeout(() => setLoadingLabel("Masih menyusun, mohon tunggu sebentar..."), 5000),
      setTimeout(() => setLoadingLabel("Permintaan ini cukup kompleks, hampir selesai..."), 12000),
    ];
    return () => timers.forEach(clearTimeout);
  }, [isLoading]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const handleCopyCode = async (code: string, id: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
      onAddNotification("Disalin!", "Kode dipindahkan ke papan klip Anda.");
    } catch (err) {
      console.error("Gagal menyalin:", err);
    }
  };

  const handleSend = async (customText?: string) => {
    const finalQuery = customText || inputText;
    if (!finalQuery.trim()) return;

    const userMsg: CodeMessage = {
      id: Date.now().toString(),
      sender: "user",
      text: finalQuery,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
    };

    const nextMessages = [...messages, userMsg];
    setMessages(nextMessages);
    setInputText("");
    setIsLoading(true);

    setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }), 100);

    try {
      const response = await fetch("/api/code", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: nextMessages.slice(-10), // last 10 turns of memory, mirroring Diana/Liana
          language: selectedLang
        })
      });

      if (!response.ok) {
        let errMsg = `Server Error (Status: ${response.status})`;
        try {
          const text = await response.text();
          try {
            const errData = JSON.parse(text);
            errMsg = errData.error || errData.message || errMsg;
          } catch {
            if (text) {
              errMsg = text.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim().substring(0, 150) || errMsg;
            }
          }
        } catch {}
        throw new Error(errMsg);
      }

      const data = await response.json();
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender: "ai",
        text: data.explanation || "Kode berhasil digenerasikan.",
        code: data.code || "// Gagal men-generate baris kode",
        language: data.language || selectedLang,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      }]);
    } catch (err: any) {
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender: "ai",
        text: `Ada gangguan saat menghubungkan ke NexonCode. Coba kirim ulang permintaanmu. (${err.message})`,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      }]);
    } finally {
      setIsLoading(false);
      setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }), 100);
    }
  };

  const handleResetChat = () => {
    if (confirm("Hapus seluruh riwayat & memori sesi coding ini?")) {
      setMessages([INITIAL_MESSAGE]);
    }
  };

  return (
    <div 
      className={`flex flex-col bg-[#0a0a0c] transition-all duration-300 ease-out ${
        isExpanded 
          ? "fixed inset-0 z-[100] m-0 rounded-none w-screen h-screen" 
          : "h-[calc(100vh-10rem)] md:h-[calc(100vh-6rem)] rounded-2xl border border-white/[0.06] overflow-hidden"
      }`}
      id="nexoncode_studio_panel"
    >
      {/* Header */}
      <div className="border-b border-white/[0.06] px-4 py-3 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-full bg-amber-500/15 flex items-center justify-center shrink-0">
            <Code2 className="w-4 h-4 text-amber-400" />
          </div>
          <div className="min-w-0">
            <div className="font-semibold text-sm text-white/90 leading-tight truncate">NexonCode</div>
            <div className="text-[11px] text-white/35 leading-tight truncate">Asisten Coding AI</div>
          </div>
        </div>
        <div className="flex items-center gap-0.5 shrink-0">
          <button 
            type="button"
            onClick={handleResetChat} 
            title="Hapus Riwayat & Memori"
            className="p-2 hover:bg-white/[0.06] rounded-lg text-white/40 hover:text-white/80 transition-colors cursor-pointer flex items-center justify-center"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          <button 
            type="button"
            onClick={() => setIsExpanded(!isExpanded)} 
            title={isExpanded ? "Kecilkan Layar" : "Perbesar Layar"}
            className="p-2 hover:bg-white/[0.06] rounded-lg text-white/40 hover:text-white/80 transition-colors cursor-pointer flex items-center justify-center"
          >
            {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Language selector strip */}
      <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-hide border-b border-white/[0.06] px-4 py-2 shrink-0">
        {LANGUAGES.map((lang) => (
          <button
            key={lang}
            type="button"
            onClick={() => setSelectedLang(lang)}
            className={`px-2.5 py-1 rounded-lg text-[11px] font-medium border transition-all cursor-pointer shrink-0 ${
              selectedLang === lang
                ? "bg-amber-500/15 border-amber-500/30 text-amber-300"
                : "bg-transparent border-white/[0.06] text-white/40 hover:text-white/70 hover:border-white/15"
            }`}
          >
            {lang}
          </button>
        ))}
      </div>

      {/* Conversation */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex gap-3 ${msg.sender === "user" ? "flex-row-reverse" : ""}`}>
              <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                msg.sender === "user" ? "bg-white/10 text-white/70" : "bg-amber-500/15 text-amber-400"
              }`}>
                {msg.sender === "user" ? null : <Code2 className="w-3.5 h-3.5" />}
              </div>

              <div className={`flex flex-col gap-1.5 min-w-0 ${msg.sender === "user" ? "items-end max-w-[85%]" : "items-start max-w-[92%] w-full"}`}>
                {msg.sender === "user" ? (
                  <div className="px-4 py-2.5 rounded-2xl bg-white/[0.07] text-white/95 text-[14.5px] leading-relaxed">
                    {msg.text}
                  </div>
                ) : (
                  <div className="w-full space-y-2.5">
                    {msg.text && (
                      <div className="text-[14.5px] leading-relaxed text-white/90">
                        {renderFormattedText(msg.text, "diana")}
                      </div>
                    )}
                    {msg.code && (
                      <div className="rounded-xl border border-white/[0.06] bg-[#08090b] overflow-hidden">
                        <div className="flex items-center justify-between px-3 py-2 border-b border-white/[0.06] bg-white/[0.02]">
                          <span className="text-[10px] font-mono text-white/40 uppercase tracking-wide">
                            {msg.language || selectedLang}
                          </span>
                          <button
                            onClick={() => handleCopyCode(msg.code!, msg.id)}
                            className="flex items-center gap-1 px-2 py-1 text-white/50 hover:text-white text-[11px] font-medium cursor-pointer transition-colors rounded-md hover:bg-white/[0.06]"
                          >
                            {copiedId === msg.id ? (
                              <>
                                <Check className="w-3 h-3 text-green-400" />
                                <span className="text-green-400">Disalin</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3" />
                                <span>Salin</span>
                              </>
                            )}
                          </button>
                        </div>
                        <div className="p-3.5 font-mono text-[12.5px] overflow-x-auto">
                          <CodeBlock code={msg.code} />
                        </div>
                      </div>
                    )}
                  </div>
                )}
                <span className="text-[10px] text-white/25 px-1">{msg.timestamp}</span>
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-full bg-amber-500/15 text-amber-400 flex items-center justify-center shrink-0 mt-0.5">
                <Code2 className="w-3.5 h-3.5" />
              </div>
              <div className="flex items-center gap-2 py-2">
                <div className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce [animation-delay:-0.3s]"></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce [animation-delay:-0.15s]"></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce"></span>
                </div>
                <span className="text-[11px] text-white/30">{loadingLabel}</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Suggested prompts on fresh session */}
      {messages.length === 1 && (
        <div className="px-4 pb-3 shrink-0">
          <div className="max-w-3xl mx-auto grid grid-cols-2 gap-2">
            {EXAMPLE_PROMPTS.map((item, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setInputText(item.q)}
                className="p-2.5 text-left bg-white/[0.04] hover:bg-white/[0.07] border border-white/[0.06] rounded-xl text-xs transition-colors cursor-pointer"
              >
                <div className="font-medium text-white/80 mb-0.5 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-amber-400" /> {item.label}
                </div>
                <div className="text-white/35 truncate text-[10px]">{item.q}</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Composer */}
      <div className="px-4 pb-4 pt-2 shrink-0">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-end gap-2 bg-white/[0.05] border border-white/10 rounded-2xl p-1.5 focus-within:border-amber-500/40 transition-colors">
            <textarea
              rows={1}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder={`Tanya NexonCode tentang ${selectedLang}...`}
              className="flex-1 self-center px-3 py-2 bg-transparent outline-none text-[14.5px] text-white/90 placeholder-white/30 resize-none font-sans max-h-32"
            />
            <button
              type="button"
              disabled={isLoading || !inputText.trim()}
              onClick={() => handleSend()}
              className="p-2.5 bg-white/90 hover:bg-white text-black rounded-xl transition-all cursor-pointer flex items-center justify-center disabled:opacity-30 disabled:cursor-not-allowed shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
          <div className="mt-1.5 text-[10px] text-white/25 text-center">
            NexonCode mengingat percakapan ini selama sesi berlangsung — lanjutkan untuk merevisi kode sebelumnya.
          </div>
        </div>
      </div>
    </div>
  );
}
