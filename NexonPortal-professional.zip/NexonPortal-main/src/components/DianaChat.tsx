import React, { useState, useEffect, useRef, DragEvent, ChangeEvent } from "react";
import { Message } from "../types";
import { 
  Send, 
  Paperclip, 
  X, 
  RefreshCw, 
  Sparkles, 
  FileText, 
  Image as ImageIcon,
  CheckCircle,
  Maximize2,
  Minimize2,
  Plus,
  GraduationCap
} from "lucide-react";

interface DianaChatProps {
  onAddNotification: (title: string, msg: string) => void;
}

export interface ChatRoom {
  id: string;
  name: string;
  messages: Message[];
}

export default function DianaChat({ onAddNotification }: DianaChatProps) {
  const [rooms, setRooms] = useState<ChatRoom[]>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("diana_chat_rooms");
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) return parsed;
        } catch (e) {
          console.warn("Failed to parse Diana chat history");
        }
      }
    }
    return [
      {
        id: "default",
        name: "Kelas Umum",
        messages: [
          {
            id: "init-diana",
            sender: "ai",
            text: "Halo! Saya **Diana**, Guru Akademik kecerdasan buatan Anda di **NexonAcademic** 🎓.\n\nSaya menguasai berbagai mata pelajaran mulai dari *Matematika, Fisika, Kimia, hingga Sejarah dan Sastra*. \n\nKamu bisa bertanya apapun, berdiskusi materi rumit, latihan ujian, atau **mengirimkan file tugas, gambar coretan rumus, atau dokumen teks** untuk saya koreksi langsung. Apa yang ingin kamu pelajari hari ini?",
            timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
          }
        ]
      }
    ];
  });
  
  const [activeRoomId, setActiveRoomId] = useState<string>("default");

  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("diana_chat_rooms", JSON.stringify(rooms));
    }
  }, [rooms]);

  const activeRoom = rooms.find(r => r.id === activeRoomId) || rooms[0];
  const messages = activeRoom.messages;

  const setMessages = (updater: Message[] | ((prev: Message[]) => Message[])) => {
    setRooms(prevRooms => prevRooms.map(r => {
      if (r.id === activeRoomId) {
        return {
          ...r,
          messages: typeof updater === "function" ? updater(r.messages) : updater
        };
      }
      return r;
    }));
  };

  const handleCreateRoom = () => {
    const name = prompt("Masukkan nama kelas baru (misal: Kelas IPA, Kelas Sejarah):");
    if (!name || !name.trim()) return;
    
    const newRoom: ChatRoom = {
      id: Date.now().toString(),
      name: name.trim(),
      messages: [
        {
          id: "init-diana-" + Date.now(),
          sender: "ai",
          text: `Halo! Selamat datang di **${name.trim()}**.\n\nMateri apa yang ingin kita bahas di kelas ini hari ini?`,
          timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
        }
      ]
    };
    
    setRooms(prev => [...prev, newRoom]);
    setActiveRoomId(newRoom.id);
  };

  const handleDeleteRoom = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (rooms.length <= 1) {
      alert("Anda harus memiliki setidaknya satu kelas.");
      return;
    }
    if (confirm("Hapus kelas ini dan semua riwayat obrolannya?")) {
      const newRooms = rooms.filter(r => r.id !== id);
      setRooms(newRooms);
      if (activeRoomId === id) {
        setActiveRoomId(newRooms[0].id);
      }
    }
  };
  
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [attachedFile, setAttachedFile] = useState<{ name: string; type: string; base64: string } | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const samplePrompts = [
    { title: "Tanya Matematika", text: "Jelaskan konsep integral tentu beserta contoh soal sehari-hari yang mudah dipahami." },
    { title: "Kuis Fisika", text: "Buatkan 3 pertanyaan kuis seru tentang Hukum Termodinamika dan beri kunci jawabannya." },
    { title: "Koreksi Tugas", text: "Tolong periksa dan jelaskan kesalahan dari file tugas kimia yang saya kirimkan ini." },
    { title: "Sintesis Sejarah", text: "Ringkas peristiwa Sumpah Pemuda dalam bentuk peta poin-poin penting kronologis." }
  ];

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const convertFileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const result = reader.result as string;
        // Strip the mime declaration prefix (e.g., data:image/png;base64, )
        const base64Data = result.split(",")[1];
        resolve(base64Data);
      };
      reader.onerror = (error) => reject(error);
    });
  };

  const processFile = async (file: File) => {
    if (file.size > 10 * 1024 * 1024) {
      alert("Maaf, ukuran berkas maksimal adalah 10MB demi kenyamanan akses.");
      return;
    }
    
    try {
      const base64 = await convertFileToBase64(file);
      setAttachedFile({
        name: file.name,
        type: file.type,
        base64: base64
      });
      onAddNotification("Berkas Tersemat!", `Berkas "${file.name}" siap dianalisis oleh Diana.`);
    } catch (err) {
      console.error("Gagal membaca file:", err);
      alert("Terjadi kesalahan saat mengunggah berkas.");
    }
  };

  const handleDrop = async (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      await processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = async (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      await processFile(e.target.files[0]);
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const finalQuery = textToSend || inputText;
    if (!finalQuery.trim() && !attachedFile) return;

    const userMsgId = Date.now().toString();
    const newUserMessage: Message = {
      id: userMsgId,
      sender: "user",
      text: finalQuery,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      fileName: attachedFile?.name,
      fileType: attachedFile?.type
    };

    setMessages(prev => [...prev, newUserMessage]);
    setInputText("");
    setIsLoading(true);
    
    // Auto scroll down
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);

    // Save attached file context to prepare body
    const payloadFile = attachedFile ? {
      base64: attachedFile.base64,
      mimeType: attachedFile.type || "application/octet-stream"
    } : null;

    // Reset attachment in UI
    setAttachedFile(null);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, newUserMessage].slice(-10), // Send last 10 messages for context
          fileData: payloadFile,
          roomName: activeRoom.name
        })
      });

      if (!response.ok) {
        let errMsg = `Server Error (Status: ${response.status})`;
        try {
          const text = await response.text();
          try {
            const errData = JSON.parse(text);
            if (errData && errData.error) {
              errMsg = errData.error;
            } else if (errData && errData.message) {
              errMsg = errData.message;
            }
          } catch {
            if (text) {
              const cleanText = text.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
              errMsg = cleanText.substring(0, 150) || errMsg;
            }
          }
        } catch {}
        throw new Error(errMsg);
      }

      const data = await response.json();
      
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender: "ai",
        text: data.text,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      }]);

    } catch (err: any) {
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender: "ai",
        text: `**Diana:** Ada masalah saat menyambungkan ke pustaka kecerdasan buatan saya. Silakan coba kirim ulang pertanyaan akademik Anda. (Error: ${err.message})`,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      }]);
    } finally {
      setIsLoading(false);
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
      }, 100);
    }
  };

  const handleResetChat = () => {
    if (confirm(`Reset ulang riwayat obrolan di kelas ${activeRoom.name}?`)) {
      setMessages([
        {
          id: "init-diana",
          sender: "ai",
          text: `Halo! Saya Diana kembali segar. Silakan tanyakan materi atau tugas di kelas **${activeRoom.name}** ini.`,
          timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  };

  return (
    <div 
      className={`flex flex-col bg-[#0a0a0c] transition-all duration-300 ease-out ${
        isExpanded 
          ? "fixed inset-0 z-[100] m-0 rounded-none w-screen h-screen" 
          : "h-[calc(100vh-10rem)] md:h-[calc(100vh-6rem)] rounded-2xl border border-white/[0.06] overflow-hidden"
      }`} 
      id="diana_chat_panel"
    >
      {/* Head — flat, minimal, no neon gradient banner */}
      <div className="border-b border-white/[0.06] px-4 py-3 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-full bg-teal-500/15 flex items-center justify-center shrink-0">
            <GraduationCap className="w-4 h-4 text-teal-400" />
          </div>
          <div className="min-w-0">
            <div className="font-semibold text-sm text-white/90 leading-tight truncate">Diana</div>
            <div className="text-[11px] text-white/35 leading-tight truncate">Guru MIPA &amp; Sastra</div>
          </div>
        </div>
        <div className="flex items-center gap-0.5 shrink-0">
          <button 
            type="button"
            onClick={handleResetChat} 
            title="Reset Obrolan Kelas" 
            className="p-2 hover:bg-white/[0.06] rounded-lg text-white/40 hover:text-white/80 transition-colors cursor-pointer flex items-center justify-center"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          <button 
            type="button"
            onClick={() => setIsExpanded(!isExpanded)} 
            title={isExpanded ? "Kecilkan Layar" : "Perbesar Layar"} 
            className="p-2 hover:bg-white/[0.06] rounded-lg text-white/40 hover:text-white/80 transition-colors cursor-pointer flex items-center justify-center"
          >
            {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Room Tabs — quiet underline-style tabs instead of colorful pill chips */}
      <div className="flex items-center bg-[#0a0a0c] overflow-x-auto border-b border-white/[0.06] scrollbar-hide px-2 shrink-0">
        {rooms.map(room => (
          <div 
            key={room.id}
            onClick={() => setActiveRoomId(room.id)}
            className={`group flex items-center gap-1.5 px-3 py-2.5 cursor-pointer whitespace-nowrap text-[13px] font-medium transition-colors border-b-2 -mb-px ${
              activeRoomId === room.id 
                ? "text-white border-teal-400" 
                : "text-white/40 hover:text-white/70 border-transparent"
            }`}
          >
            <span>{room.name}</span>
            <button 
              onClick={(e) => handleDeleteRoom(room.id, e)}
              className="text-white/0 group-hover:text-white/30 hover:!text-rose-400 p-0.5 rounded transition-colors"
              title="Hapus Kelas"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        ))}
        <button 
          onClick={handleCreateRoom}
          className="flex items-center gap-1 px-3 py-2.5 cursor-pointer whitespace-nowrap text-[13px] font-medium text-white/30 hover:text-white/70 transition-colors shrink-0"
          title="Tambah Kelas Baru"
        >
          <Plus className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Messages Stage */}
      <div 
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`flex-1 overflow-y-auto relative transition-all duration-200 ${isDragOver ? "bg-teal-950/10 ring-2 ring-teal-500/30 ring-inset" : ""}`}
      >
        {/* Drag over overlay */}
        {isDragOver && (
          <div className="absolute inset-0 bg-[#0a0a0c]/95 backdrop-blur-sm flex flex-col items-center justify-center border-2 border-dashed border-teal-400/50 m-2 rounded-xl z-10 pointer-events-none">
            <div className="p-4 bg-teal-500/15 text-teal-400 rounded-full mb-3">
              <Paperclip className="w-7 h-7" />
            </div>
            <p className="text-teal-300 font-medium text-sm">Lepaskan Berkas di Sini</p>
            <p className="text-white/40 text-xs mt-1">Gambar, soal, PDF, atau teks (maks 10MB)</p>
          </div>
        )}

        <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
          {messages.map((msg) => (
            <div 
              key={msg.id}
              className={`flex gap-3 ${msg.sender === "user" ? "flex-row-reverse" : ""}`}
            >
              {/* Avatar — small and quiet, not a glowing badge */}
              <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 mt-0.5 text-[10px] font-bold ${
                msg.sender === "user" ? "bg-white/10 text-white/70" : "bg-teal-500/15 text-teal-400"
              }`}>
                {msg.sender === "user" ? "" : <GraduationCap className="w-3.5 h-3.5" />}
              </div>
              
              <div className={`flex flex-col gap-1 min-w-0 ${msg.sender === "user" ? "items-end max-w-[85%]" : "items-start max-w-[88%]"}`}>
                <div className={`leading-relaxed text-[14.5px] ${
                  msg.sender === "user" 
                    ? "px-4 py-2.5 rounded-2xl bg-white/[0.07] text-white/95" 
                    : "text-white/90"
                }`}>
                  {/* Optional attachment label above text */}
                  {msg.fileName && (
                    <div className="mb-2 py-1.5 px-2 bg-black/30 rounded-lg flex items-center gap-2 text-xs text-white/55 border border-white/[0.06] font-mono">
                      {msg.fileType?.includes("image") ? <ImageIcon className="w-3.5 h-3.5 text-blue-400 shrink-0" /> : <FileText className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                      <span className="truncate max-w-[150px]" title={msg.fileName}>{msg.fileName}</span>
                      <CheckCircle className="w-3.5 h-3.5 text-green-400 ml-auto shrink-0" />
                    </div>
                  )}
                  {renderFormattedText(msg.text, "diana")}
                </div>
                <span className="text-[10px] text-white/25 px-1">{msg.timestamp}</span>
              </div>
            </div>
          ))}
          
          {isLoading && (
            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-full bg-teal-500/15 text-teal-400 flex items-center justify-center shrink-0 mt-0.5">
                <GraduationCap className="w-3.5 h-3.5" />
              </div>
              <div className="flex items-center gap-1.5 py-2">
                <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce [animation-delay:-0.3s]"></span>
                <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce [animation-delay:-0.15s]"></span>
                <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce"></span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Suggested Prompts — shown only at the start of a fresh room */}
      {messages.length === 1 && (
        <div className="px-4 pb-3 shrink-0">
          <div className="max-w-3xl mx-auto grid grid-cols-2 lg:grid-cols-4 gap-2">
            {samplePrompts.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setInputText(p.text);
                }}
                className="p-2.5 text-left bg-white/[0.04] hover:bg-white/[0.07] border border-white/[0.06] rounded-xl text-xs transition-colors cursor-pointer"
              >
                <div className="font-medium text-white/80 mb-0.5 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-teal-400" /> {p.title}
                </div>
                <div className="text-white/35 truncate text-[10px]">{p.text}</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input controls panel — single rounded composer, like Claude/ChatGPT */}
      <div className="px-4 pb-4 pt-2 shrink-0">
        <div className="max-w-3xl mx-auto">
          {/* Attachment preview if selected */}
          {attachedFile && (
            <div className="mb-2 p-2 bg-teal-500/10 border border-teal-500/25 rounded-lg flex items-center justify-between text-xs animate-fadeIn">
              <div className="flex items-center gap-2 font-medium text-teal-300">
                {attachedFile.type.includes("image") ? <ImageIcon className="w-4 h-4 text-teal-400" /> : <FileText className="w-4 h-4 text-teal-400" />}
                <span className="truncate max-w-[220px]">{attachedFile.name}</span>
              </div>
              <button 
                onClick={() => setAttachedFile(null)} 
                className="p-1 hover:bg-teal-500/20 text-teal-400 rounded-full cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          <div className="flex items-end gap-2 bg-white/[0.05] border border-white/10 rounded-2xl p-1.5 focus-within:border-teal-500/40 transition-colors">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*,.txt,.json,.csv,.pdf"
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              title="Sematkan berkas atau gambar tugas"
              className="p-2.5 text-white/40 hover:text-teal-400 rounded-xl transition-colors cursor-pointer flex items-center justify-center shrink-0"
            >
              <Paperclip className="w-4.5 h-4.5" />
            </button>
            
            <textarea
              rows={1}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder={attachedFile ? "Beri pertanyaan terkait berkas ini..." : "Tanya Diana apa saja..."}
              className="flex-1 self-center px-2 py-2 bg-transparent outline-none text-[14.5px] text-white/90 placeholder-white/30 resize-none font-sans max-h-32"
            />

            <button
              type="button"
              disabled={!inputText.trim() && !attachedFile}
              onClick={() => handleSendMessage()}
              className="p-2.5 bg-white/90 hover:bg-white text-black rounded-xl transition-all cursor-pointer flex items-center justify-center disabled:opacity-30 disabled:cursor-not-allowed shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
          <div className="mt-1.5 text-[10px] text-white/25 text-center">
            Diana bisa saja keliru. Periksa kembali informasi penting.
          </div>
        </div>
      </div>
    </div>
  );
}

// Custom Markdown parser for premium UI and correct formatting of raw **bold** and *italics*
export function parseInlineStyles(text: string, theme: "diana" | "liana" = "diana"): React.ReactNode[] {
  if (!text) return [];
  const parts = text.split(/(\*\*.*?\*\*|\*.*?\*)/g);
  const boldClass = theme === "diana" ? "font-extrabold text-teal-300" : "font-extrabold text-rose-350";
  const italicClass = theme === "diana" ? "italic text-teal-200" : "italic text-rose-200";
  return parts.map((part, index) => {
    if (part.startsWith("**") && part.endsWith("**")) {
      return <strong key={index} className={boldClass}>{part.slice(2, -2)}</strong>;
    }
    if (part.startsWith("*") && part.endsWith("*")) {
      return <em key={index} className={italicClass}>{part.slice(1, -1)}</em>;
    }
    return part;
  });
}

export function renderFormattedText(text: string, theme: "diana" | "liana" = "diana") {
  if (!text) return null;
  const lines = text.split("\n");
  let inList = false;
  const listItems: React.ReactNode[] = [];
  const elements: React.ReactNode[] = [];

  const flushList = (keyPrefix: string) => {
    if (listItems.length > 0) {
      elements.push(
        <ul key={`ul-${keyPrefix}`} className="list-disc pl-5 my-2 space-y-1.5 text-white/80">
          {[...listItems]}
        </ul>
      );
      listItems.length = 0; // clear
    }
  };

  lines.forEach((line, index) => {
    const trimmed = line.trim();
    
    // Bullet point list item
    if (trimmed.startsWith("* ") || trimmed.startsWith("- ")) {
      inList = true;
      const content = trimmed.slice(2);
      listItems.push(
        <li key={`li-${index}`} className="leading-relaxed">
          {parseInlineStyles(content, theme)}
        </li>
      );
    } else {
      if (inList) {
        flushList(String(index));
        inList = false;
      }

      if (trimmed === "") {
        elements.push(<div key={`spacer-${index}`} className="h-2" />);
      } else if (trimmed.startsWith("### ")) {
        elements.push(
          <h3 key={`h3-${index}`} className="text-sm font-bold text-white mt-3.5 mb-1 tracking-tight font-display">
            {parseInlineStyles(trimmed.slice(4), theme)}
          </h3>
        );
      } else if (trimmed.startsWith("## ")) {
        elements.push(
          <h2 key={`h2-${index}`} className="text-base font-bold text-white mt-4.5 mb-1.5 tracking-tight font-display">
            {parseInlineStyles(trimmed.slice(3), theme)}
          </h2>
        );
      } else if (trimmed.startsWith("# ")) {
        elements.push(
          <h1 key={`h1-${index}`} className="text-lg font-bold text-white mt-5 mb-2 tracking-tight font-display">
            {parseInlineStyles(trimmed.slice(2), theme)}
          </h1>
        );
      } else {
        elements.push(
          <p key={`p-${index}`} className="leading-relaxed mb-2 text-white/90">
            {parseInlineStyles(line, theme)}
          </p>
        );
      }
    }
  });

  if (inList) {
    flushList("end");
  }

  return <div className="space-y-1">{elements}</div>;
}

